# Roadmap

## 0.2 — installer foundation

- local persistent state
- content library
- scene-based clipping
- vertical rendering
- publisher drafts
- connector status
- system repair/backups
- installer build pipeline

## 0.3 — local intelligence

- faster-whisper local transcription
- SRT/ASS generation
- transcript viewer
- semantic clip ranking
- audio-energy scoring
- configurable clip durations
- subtitle presets

## 0.4 — real account connectivity

- Google OAuth + YouTube upload/sync
- TikTok developer OAuth adapter
- Meta/Instagram OAuth adapter
- encrypted token storage
- connector diagnostics

## 0.5 — publishing + sync

- upload queue
- retry policy
- publication status sync
- normalized metric snapshots
- scheduler

## 0.6 — intelligent reframing

- face detection/tracking
- speaker-aware 9:16 crops
- subtitle editor
- variants / hooks

## 1.0

- stable multi-account clipping command center
- updater release channel
- richer analytics/campaign workflows

## v0.4.0
- Trend Radar engine and local scheduler
- YouTube trend discovery adapter
- Approval Queue + rights state
- trend snapshots/history

## Next
- OAuth production connectors
- local Whisper + semantic clipping
- subtitles and creative variants
- supported TikTok/Instagram trend adapters when an appropriate official data product is available
