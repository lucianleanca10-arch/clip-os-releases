# Social API setup status

The 0.2 application deliberately does not contain developer secrets or fabricated authentication.

Each platform appears in Accounts with `requires_setup` and a list of external prerequisites. OAuth implementation belongs to the connector milestone.

Never commit client secrets, access tokens or refresh tokens to the repository. Future token storage should use Windows-protected credential storage where possible.

## YouTube OAuth in CLIP OS 0.4.1

1. Enable **YouTube Data API v3** in Google Cloud.
2. Configure the OAuth consent screen and add your Google account as a test user while the app is in testing.
3. Create an **OAuth Client ID → Desktop app**.
4. Download the JSON file.
5. In CLIP OS open **Accounts → YouTube · Real OAuth → Import client_secret.json**.
6. Click **Connect another YouTube account** and authorize in the browser.
7. Repeat the connect action for each additional Google/YouTube account.

The JSON and OAuth tokens are encrypted locally by Electron `safeStorage`; they are not stored in SQLite or release artifacts.
