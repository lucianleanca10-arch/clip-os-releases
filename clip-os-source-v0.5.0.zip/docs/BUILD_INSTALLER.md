# Windows installer build

CLIP OS 0.2 uses two packaging stages.

## 1. Python backend

`build-installer.ps1` runs PyInstaller against `backend/entry.py` and creates:

```text
resources/backend/clipos-backend.exe
```

Electron starts this process silently when the packaged desktop app launches.

## 2. Electron application

The script builds the Vite UI, copies FFmpeg/FFprobe into `resources/bin`, then runs Electron Builder with NSIS.

Expected artifact:

```text
release/CLIP-OS-Setup-0.2.0.exe
```

## Runtime dependencies

The final installed application is designed not to require a separately installed Python or Node runtime.

## Unsigned executable

The build has no code-signing certificate configured. Windows can therefore show an Unknown Publisher / SmartScreen warning. This is distinct from antivirus software.

## Data safety

The installer only owns application binaries. User state is stored under `%APPDATA%\ClipOS`, while media is stored under `%USERPROFILE%\Videos\ClipOS`.
