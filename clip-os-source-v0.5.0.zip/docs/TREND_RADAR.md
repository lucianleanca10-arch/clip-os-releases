# Trend Radar — v0.4.0

Trend Radar is a local opportunity detector. It stores snapshots of recent public metrics, scores acceleration/freshness/engagement, and sends promising items to an Approval Queue.

## Current live source

### YouTube
CLIP OS can query the official YouTube Data API using a user-supplied API key. It searches recent short-duration videos for configured niches and region, then fetches public statistics and stores snapshots locally.

The score is heuristic, not a scientific or platform-provided ranking. It combines:

- current views/hour,
- freshness inside the configured window,
- public engagement (likes + comments relative to views),
- positive acceleration when a prior snapshot exists.

The default threshold is 70/100.

## TikTok and Instagram

The normal publishing/display APIs used by CLIP OS are not treated as a general public trend feed. CLIP OS therefore marks these sources as **limited** instead of scraping pages or inventing trend data.

TikTok has Research API access for qualifying research use cases, but that is not assumed to be available for this commercial clipping workflow. Future source adapters can be added if the account has an appropriate supported data product.

## Scheduler

Automatic scans are limited to once per hour or slower. The default window is three hours. This avoids a tight polling loop and leaves room for API quotas.

The scheduler runs inside the local backend and writes each run to `trend_runs`.

## Approval Queue and rights

Editorial approval and reuse rights are separate states.

A user can mark a source as:

- unknown,
- own content,
- creator-authorized,
- licensed,
- Creative Commons / compatible license.

CLIP OS does **not** automatically download a YouTube page result because the Data API does not provide a reusable source-media download URL. Future adapters may auto-download only when they provide a direct asset URL that is explicitly authorized for reuse.

## Database tables

- `trend_items`
- `trend_snapshots`
- `trend_runs`

Database schema version: 4.
