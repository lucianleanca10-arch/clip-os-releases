# TikTok setup for CLIP OS v0.4.4

CLIP OS uses TikTok's official **Desktop Login Kit** for account authorization. It does not ask for or store your TikTok password.

## 1. Create a TikTok developer app

Open `https://developers.tiktok.com/apps/` and create/select your app. Copy the **Client Key** and **Client Secret**.

## 2. Add Login Kit for Desktop

Enable Login Kit and configure the Desktop platform. Add this redirect URI exactly:

```text
http://127.0.0.1:*/callback/
```

TikTok allows loopback hosts (`localhost` / `127.0.0.1`) and wildcard ports for desktop applications. CLIP OS starts a temporary local callback server on a random port each time you connect.

## 3. Configure scopes

Start with:

```text
user.info.basic
```

Optional scopes in CLIP OS:

- `video.list` — read the authorized user's public videos.
- `video.upload` — upload a video to the user's TikTok inbox as a draft; the user completes editing/posting in TikTok.
- `video.publish` — Direct Post to TikTok. This must be approved for your app and TikTok audit/review restrictions apply.

Do not select a scope in CLIP OS unless it is enabled/approved in the TikTok developer portal, otherwise TikTok can reject authorization.

## 4. Save credentials in CLIP OS

Accounts → TikTok → paste Client Key + Client Secret → **Save TikTok API credentials**. The secret is encrypted locally with Windows `safeStorage`.

## 5. Connect an account

Press **Connect TikTok account**. The browser opens TikTok, you log in/choose the account, review scopes, and approve. TikTok redirects to the temporary local callback. CLIP OS exchanges the code for access/refresh tokens and stores them encrypted.

A successful account appears in Accounts with status `connected`.

## Posting caveat

OAuth connection and posting permission are different. A connected TikTok account can exist with only `user.info.basic`. Draft upload requires `video.upload`; Direct Post requires `video.publish` and TikTok approval. Unaudited Direct Post clients may be restricted to private viewing.
