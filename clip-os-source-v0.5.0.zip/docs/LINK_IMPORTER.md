# Link Importer

CLIP OS v0.5.0 can import supported public links from YouTube, TikTok and Instagram Reels directly into the local Content Library. Exact duplicate media is detected by SHA-256 and reused instead of wasting disk space.

## Usage

1. Open **Link Importer**.
2. Paste one URL per line (up to 20).
3. Confirm you own the media or have permission/license to download and reuse it.
4. Click **Import links**.
5. Successful imports appear in **Content** and can be sent to Clipper.

## Media behavior

The importer requests the best/original media variant exposed by the service/extractor and uses local FFmpeg to merge tracks when necessary. It does not remove or conceal embedded watermarks/attribution, and it does not bypass private or login-only content. Some Instagram Reels may require authentication and therefore will not import from a bare public URL.

## Engine

The packaged backend includes `yt-dlp`. The installer build bundles that library into `clipos-backend.exe`, while FFmpeg/FFprobe remain bundled under the existing CLIP OS resources.
