# CLIP OS 0.2 architecture

```text
Electron desktop shell
  ├─ React/Vite UI (compiled into app)
  └─ clipos-backend.exe (PyInstaller)
       ├─ FastAPI local API on 127.0.0.1:8765
       ├─ SQLite state database
       ├─ FFmpeg / FFprobe
       ├─ Media workspace
       └─ platform connector layer (OAuth implementation follows)
```

## Persistence boundary

Program files and user data are intentionally separated.

- Program: Electron install directory under LocalAppData Programs.
- State: `%APPDATA%\ClipOS`.
- Media: `%USERPROFILE%\Videos\ClipOS`.

This is the basis for safe repair, reinstall and version upgrades.

## Platform connectors

0.2 registers connector records for YouTube, TikTok and Instagram with `requires_setup`. No record becomes `connected` until a real OAuth authorization flow succeeds in a later milestone.

## Database

Current schema version: 2.

Tables: settings, sources, clips, accounts, publications, metric_snapshots, jobs.

Before future schema upgrades, the migration layer must back up the current database and migrate in place.
