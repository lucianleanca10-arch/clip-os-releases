$ErrorActionPreference = 'Stop'
$owner = 'lucianleanca10-arch'
$repo = 'clip-os-releases'
Write-Host "CLIP OS update channel: $owner/$repo"
Write-Host "Feed: https://github.com/$owner/$repo/releases/latest/download"
Write-Host "This repository is now the default in CLIP OS v0.3.1+."
Write-Host "Use .\setup-release-channel.ps1 once to create/verify the repo, then .\publish-release.ps1 to publish releases."
