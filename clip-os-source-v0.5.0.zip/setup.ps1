$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

function Find-Python {
  if (Get-Command py -ErrorAction SilentlyContinue) { return @('py','-3') }
  if (Get-Command python -ErrorAction SilentlyContinue) { return @('python') }
  throw 'Python 3.11+ is required. Install it with: winget install Python.Python.3.12'
}

if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js 20+ is required. Install it with: winget install OpenJS.NodeJS.LTS' }
$nodeMajor = [int]((node -v).TrimStart('v').Split('.')[0])
if ($nodeMajor -lt 20) { throw 'Node.js 20+ is required.' }

$py = Find-Python
if (-not (Test-Path '.venv\Scripts\python.exe')) {
  if ($py.Count -eq 2) { & $py[0] $py[1] -m venv .venv } else { & $py[0] -m venv .venv }
}
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt

npm install
npm --prefix frontend install

if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
  Write-Host 'FFmpeg was not found. Attempting a zero-cost install with winget...'
  if (Get-Command winget -ErrorAction SilentlyContinue) {
    winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements
    Write-Host 'Reopen PowerShell after setup if ffmpeg is still not visible in PATH.'
  } else {
    Write-Warning 'winget is unavailable. Install FFmpeg manually before clipping/rendering.'
  }
}
Write-Host ''
Write-Host 'CLIP OS development environment is ready.' -ForegroundColor Green
Write-Host 'Run: .\dev.ps1'
Write-Host 'Build installer: .\build-installer.ps1'
