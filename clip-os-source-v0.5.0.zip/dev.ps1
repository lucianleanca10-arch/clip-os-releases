$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
if (-not (Test-Path '.venv\Scripts\python.exe')) { throw 'Run .\setup.ps1 first.' }
$env:PATH = "$PSScriptRoot\.venv\Scripts;$env:PATH"
npm run dev
