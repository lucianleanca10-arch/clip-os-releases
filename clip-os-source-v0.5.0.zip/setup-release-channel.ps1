$ErrorActionPreference = 'Stop'

function Assert-LastExitCode([string]$label) {
  if ($LASTEXITCODE -ne 0) { throw "$label failed (exit code $LASTEXITCODE)." }
}

$owner = 'lucianleanca10-arch'
$repo = 'clip-os-releases'

if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
  Write-Host "GitHub CLI not found. Installing with winget..."
  winget install --id GitHub.cli -e --source winget
  Assert-LastExitCode 'GitHub CLI installation'
  Write-Host "GitHub CLI was installed. Close this PowerShell window, open a new one in this folder, and run .\setup-release-channel.ps1 again."
  exit 0
}

& gh auth status *> $null
if ($LASTEXITCODE -ne 0) {
  Write-Host "GitHub CLI is not authenticated. Opening the GitHub login flow..."
  & gh auth login --web --git-protocol https
  Assert-LastExitCode 'GitHub authentication'
}

& gh repo view "$owner/$repo" *> $null
if ($LASTEXITCODE -ne 0) {
  Write-Host "Creating public release-only repository $owner/$repo..."
  & gh repo create "$owner/$repo" --public --description "CLIP OS release channel and auto-update artifacts" --add-readme
  Assert-LastExitCode 'GitHub repository creation'
} else {
  Write-Host "Repository already exists: $owner/$repo"
}

Write-Host ""
Write-Host "Release channel ready."
Write-Host "Repository: https://github.com/$owner/$repo"
Write-Host "Update feed: https://github.com/$owner/$repo/releases/latest/download"
Write-Host ""
Write-Host "Next: run .\publish-release.ps1 to build and publish CLIP OS."
