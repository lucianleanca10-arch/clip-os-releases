const { NsisUpdater } = require('electron-updater');
const path = require('path');
const fs = require('fs');

function createUpdater({ app, ipcMain, getWindow }) {
  let updater = null;
  let config = loadConfig();
  let state = {
    supported: app.isPackaged && process.platform === 'win32',
    configured: Boolean(config.owner && config.repo),
    checking: false,
    downloading: false,
    available: false,
    downloaded: false,
    currentVersion: app.getVersion(),
    latestVersion: null,
    progress: 0,
    lastCheckedAt: null,
    message: config.owner && config.repo ? 'Ready to check for updates.' : 'Update channel is not configured yet.',
    error: null,
  };

  function configPath() { return path.join(app.getPath('userData'), 'updater-config.json'); }
  function loadConfig() {
    try {
      const raw = JSON.parse(fs.readFileSync(path.join(app.getPath('userData'), 'updater-config.json'), 'utf8'));
      return {
        owner: String(raw.owner || '').trim(),
        repo: String(raw.repo || '').trim(),
        autoCheck: raw.autoCheck !== false,
      };
    } catch (_) {
      return { owner: 'lucianleanca10-arch', repo: 'clip-os-releases', autoCheck: true };
    }
  }
  function saveConfig(next) {
    const owner = String(next.owner || '').trim();
    const repo = String(next.repo || '').trim();
    const validSlug = /^[A-Za-z0-9_.-]+$/;
    if ((owner && !validSlug.test(owner)) || (repo && !validSlug.test(repo))) {
      throw new Error('GitHub owner/repository contains invalid characters.');
    }
    config = {
      owner,
      repo,
      autoCheck: next.autoCheck !== false,
    };
    fs.mkdirSync(path.dirname(configPath()), { recursive: true });
    fs.writeFileSync(configPath(), JSON.stringify(config, null, 2), 'utf8');
    state.configured = Boolean(config.owner && config.repo);
    state.message = state.configured ? 'Update channel configured.' : 'Update channel is not configured yet.';
    state.error = null;
    emit();
    resetUpdater();
    return { ...config, feedUrl: feedUrl() };
  }
  function feedUrl() {
    if (!config.owner || !config.repo) return null;
    return `https://github.com/${encodeURIComponent(config.owner)}/${encodeURIComponent(config.repo)}/releases/latest/download`;
  }
  function emit(extra = {}) {
    state = { ...state, ...extra };
    const win = getWindow();
    if (win && !win.isDestroyed()) win.webContents.send('update:event', state);
  }
  function resetUpdater() {
    updater = null;
    state.available = false;
    state.downloaded = false;
    state.latestVersion = null;
    state.progress = 0;
    state.downloading = false;
  }
  function ensureUpdater() {
    if (!app.isPackaged) throw new Error('Auto-update is available only in the installed build.');
    if (process.platform !== 'win32') throw new Error('This CLIP OS updater is currently configured for Windows builds.');
    const url = feedUrl();
    if (!url) throw new Error('Configure the GitHub owner and repository in Settings → Updates first.');
    if (updater) return updater;
    updater = new NsisUpdater({ provider: 'generic', url, useMultipleRangeRequest: false });
    updater.autoDownload = false;
    updater.autoInstallOnAppQuit = true;
    updater.allowPrerelease = false;

    updater.on('checking-for-update', () => emit({ checking: true, message: 'Checking for updates…', error: null }));
    updater.on('update-available', (info) => emit({ checking: false, available: true, downloaded: false, latestVersion: info.version, lastCheckedAt: new Date().toISOString(), message: `CLIP OS ${info.version} is available.` }));
    updater.on('update-not-available', (info) => emit({ checking: false, available: false, downloaded: false, latestVersion: info.version || app.getVersion(), lastCheckedAt: new Date().toISOString(), message: 'You already have the latest version.' }));
    updater.on('download-progress', (p) => emit({ downloading: true, progress: Math.max(0, Math.min(100, Number(p.percent || 0))), message: `Downloading update… ${Math.round(p.percent || 0)}%` }));
    updater.on('update-downloaded', (info) => emit({ checking: false, downloading: false, available: true, downloaded: true, latestVersion: info.version, progress: 100, message: 'Update downloaded. Restart CLIP OS to install it.' }));
    updater.on('error', (err) => emit({ checking: false, downloading: false, error: String(err && err.message ? err.message : err), message: 'Update failed.' }));
    return updater;
  }

  async function check(silent = false) {
    if (state.checking) return state;
    try {
      const u = ensureUpdater();
      if (!silent) emit({ message: 'Checking for updates…', error: null });
      await u.checkForUpdates();
      return state;
    } catch (err) {
      emit({ checking: false, error: String(err && err.message ? err.message : err), message: 'Could not check for updates.' });
      throw err;
    }
  }
  async function download() {
    if (state.downloading) return state;
    const u = ensureUpdater();
    if (!state.available) await u.checkForUpdates();
    emit({ downloading: true, message: 'Downloading update…', error: null });
    await u.downloadUpdate();
    return state;
  }
  function install() {
    if (!updater || !state.downloaded) throw new Error('No downloaded update is ready to install.');
    updater.quitAndInstall(false, true);
    return { ok: true };
  }

  ipcMain.handle('update:getState', () => ({ ...state }));
  ipcMain.handle('update:getConfig', () => ({ ...config, feedUrl: feedUrl() }));
  ipcMain.handle('update:setConfig', (_event, next) => saveConfig(next || {}));
  ipcMain.handle('update:check', () => check(false));
  ipcMain.handle('update:download', () => download());
  ipcMain.handle('update:install', () => install());

  function autoCheckSoon() {
    if (!app.isPackaged || !config.autoCheck || !config.owner || !config.repo) return;
    setTimeout(() => check(true).catch(() => {}), 7000);
    const timer = setInterval(() => check(true).catch(() => {}), 6 * 60 * 60 * 1000);
    if (timer.unref) timer.unref();
  }

  return { autoCheckSoon, getState: () => ({ ...state }), getConfig: () => ({ ...config }) };
}

module.exports = { createUpdater };
