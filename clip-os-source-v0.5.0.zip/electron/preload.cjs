const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('clipOS', {
  runtime: {
    getConfig: () => ipcRenderer.sendSync('runtime:getConfig'),
    openApiPath: (path) => ipcRenderer.invoke('app:openApiPath', path),
    openFolder: (kind) => ipcRenderer.invoke('app:openFolder', kind),
  },
  vault: {
    available: () => ipcRenderer.invoke('vault:available'),
    save: (entry) => ipcRenderer.invoke('vault:save', entry),
    get: (key) => ipcRenderer.invoke('vault:get', key),
    remove: (key) => ipcRenderer.invoke('vault:remove', key),
    list: () => ipcRenderer.invoke('vault:list'),
  },
  oauth: {
    youtubeStatus: () => ipcRenderer.invoke('oauth:youtubeStatus'),
    importYouTubeClient: () => ipcRenderer.invoke('oauth:importYouTubeClient'),
    connectYouTube: () => ipcRenderer.invoke('oauth:connectYouTube'),
    tiktokStatus: () => ipcRenderer.invoke('oauth:tiktokStatus'),
    saveTikTokClient: (config) => ipcRenderer.invoke('oauth:saveTikTokClient', config),
    updateTikTokScopes: (scopes) => ipcRenderer.invoke('oauth:updateTikTokScopes', scopes),
    connectTikTok: () => ipcRenderer.invoke('oauth:connectTikTok'),
  },
  openExternal: (url) => ipcRenderer.invoke('app:openExternal', url),
  updates: {
    getState: () => ipcRenderer.invoke('update:getState'),
    getConfig: () => ipcRenderer.invoke('update:getConfig'),
    setConfig: (config) => ipcRenderer.invoke('update:setConfig', config),
    check: () => ipcRenderer.invoke('update:check'),
    download: () => ipcRenderer.invoke('update:download'),
    install: () => ipcRenderer.invoke('update:install'),
    onEvent: (callback) => {
      const listener = (_event, payload) => callback(payload);
      ipcRenderer.on('update:event', listener);
      return () => ipcRenderer.removeListener('update:event', listener);
    },
  },
});
