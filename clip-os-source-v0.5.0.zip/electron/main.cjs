const { app, BrowserWindow, dialog, shell, ipcMain, safeStorage } = require('electron');
const { spawn } = require('child_process');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const http = require('http');
const { createUpdater } = require('./updater.cjs');

let backend = null;
let mainWindow = null;
let updaterController = null;
let backendPort = 8765;
const apiToken = crypto.randomBytes(32).toString('hex');
const hasSingleInstanceLock = app.requestSingleInstanceLock();
if (!hasSingleInstanceLock) app.quit();

app.on('second-instance', () => {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
});
function vaultFile() {
  return path.join(app.getPath('userData'), 'secure-vault.json');
}
function readVault() {
  try { return JSON.parse(fs.readFileSync(vaultFile(), 'utf8')); } catch (_) { return {}; }
}
function writeVault(data) {
  fs.mkdirSync(path.dirname(vaultFile()), { recursive: true });
  fs.writeFileSync(vaultFile(), JSON.stringify(data, null, 2), { encoding: 'utf8', mode: 0o600 });
}
function secureSaveJson(key, value) {
  if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows secure storage is not available');
  const data = readVault();
  data[key] = {
    kind: 'json',
    payload: safeStorage.encryptString(JSON.stringify(value)).toString('base64'),
    updatedAt: new Date().toISOString(),
  };
  writeVault(data);
}
function secureGetJson(key) {
  if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows secure storage is not available');
  const item = readVault()[String(key)];
  if (!item || item.kind !== 'json' || !item.payload) return null;
  return JSON.parse(safeStorage.decryptString(Buffer.from(item.payload, 'base64')));
}
function b64url(buffer) {
  return Buffer.from(buffer).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}
async function importYouTubeClient() {
  const result = await dialog.showOpenDialog({
    title: 'Import YouTube OAuth client_secret.json',
    properties: ['openFile'],
    filters: [{ name: 'Google OAuth JSON', extensions: ['json'] }],
  });
  if (result.canceled || !result.filePaths[0]) return { ok: false, canceled: true };
  const raw = JSON.parse(fs.readFileSync(result.filePaths[0], 'utf8'));
  const client = raw.installed;
  if (!client || !client.client_id || !client.client_secret || !client.auth_uri || !client.token_uri) {
    throw new Error('This is not a Google OAuth Desktop app credentials file. Create an OAuth Client ID of type Desktop app.');
  }
  secureSaveJson('oauth:youtube:client', {
    client_id: client.client_id,
    client_secret: client.client_secret,
    project_id: client.project_id || raw.project_id || '',
    auth_uri: client.auth_uri,
    token_uri: client.token_uri,
  });
  return { ok: true, projectId: client.project_id || raw.project_id || '', clientIdHint: `${client.client_id.slice(0, 12)}…${client.client_id.slice(-12)}` };
}
function youtubeClientStatus() {
  try {
    const c = secureGetJson('oauth:youtube:client');
    return c ? { configured: true, projectId: c.project_id || '', clientIdHint: `${c.client_id.slice(0, 12)}…${c.client_id.slice(-12)}` } : { configured: false };
  } catch (e) {
    return { configured: false, error: String(e) };
  }
}
async function connectYouTubeAccount() {
  const client = secureGetJson('oauth:youtube:client');
  if (!client) throw new Error('Import a Google Desktop OAuth client JSON first.');
  const verifier = b64url(crypto.randomBytes(48));
  const challenge = b64url(crypto.createHash('sha256').update(verifier).digest());
  const state = b64url(crypto.randomBytes(24));
  const server = http.createServer();
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  const address = server.address();
  const redirectUri = `http://127.0.0.1:${address.port}`;
  const scopes = [
    'openid',
    'email',
    'https://www.googleapis.com/auth/youtube.readonly',
    'https://www.googleapis.com/auth/youtube.upload',
  ];
  const authUrl = new URL(client.auth_uri || 'https://accounts.google.com/o/oauth2/v2/auth');
  authUrl.searchParams.set('client_id', client.client_id);
  authUrl.searchParams.set('redirect_uri', redirectUri);
  authUrl.searchParams.set('response_type', 'code');
  authUrl.searchParams.set('scope', scopes.join(' '));
  authUrl.searchParams.set('access_type', 'offline');
  authUrl.searchParams.set('prompt', 'consent select_account');
  authUrl.searchParams.set('include_granted_scopes', 'true');
  authUrl.searchParams.set('state', state);
  authUrl.searchParams.set('code_challenge', challenge);
  authUrl.searchParams.set('code_challenge_method', 'S256');

  const code = await new Promise(async (resolve, reject) => {
    const timeout = setTimeout(() => { try { server.close(); } catch (_) {} reject(new Error('Google authorization timed out.')); }, 5 * 60 * 1000);
    server.on('request', (req, res) => {
      try {
        const u = new URL(req.url, redirectUri);
        if (u.searchParams.get('error')) throw new Error(`Google authorization failed: ${u.searchParams.get('error')}`);
        if (u.searchParams.get('state') !== state) throw new Error('OAuth state mismatch. Please retry.');
        const value = u.searchParams.get('code');
        if (!value) throw new Error('Google did not return an authorization code.');
        clearTimeout(timeout);
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end('<!doctype html><html><body style="font-family:system-ui;background:#0b0d12;color:#fff;padding:40px"><h2>CLIP OS connected to Google</h2><p>You can close this tab and return to CLIP OS.</p></body></html>');
        server.close();
        resolve(value);
      } catch (e) {
        clearTimeout(timeout);
        res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end(String(e));
        server.close();
        reject(e);
      }
    });
    try { await shell.openExternal(authUrl.toString()); } catch (e) { clearTimeout(timeout); server.close(); reject(e); }
  });

  const tokenBody = new URLSearchParams({
    code,
    client_id: client.client_id,
    client_secret: client.client_secret,
    redirect_uri: redirectUri,
    grant_type: 'authorization_code',
    code_verifier: verifier,
  });
  const tokenRes = await fetch(client.token_uri || 'https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: tokenBody.toString(),
  });
  const tokens = await tokenRes.json();
  if (!tokenRes.ok || !tokens.access_token) throw new Error(tokens.error_description || tokens.error || 'Google token exchange failed.');

  const [channelRes, userRes] = await Promise.all([
    fetch('https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&mine=true', { headers: { Authorization: `Bearer ${tokens.access_token}` } }),
    fetch('https://openidconnect.googleapis.com/v1/userinfo', { headers: { Authorization: `Bearer ${tokens.access_token}` } }),
  ]);
  const channelData = await channelRes.json();
  const userData = userRes.ok ? await userRes.json() : {};
  if (!channelRes.ok) throw new Error(channelData?.error?.message || 'Could not read the YouTube channel.');
  const channel = channelData.items && channelData.items[0];
  if (!channel) throw new Error('This Google account does not expose a YouTube channel. Create a channel first and retry.');
  const vaultKey = `oauth:youtube:${channel.id}`;
  secureSaveJson(vaultKey, {
    ...tokens,
    scopes,
    client_id: client.client_id,
    obtained_at: new Date().toISOString(),
    channel_id: channel.id,
  });
  return {
    ok: true,
    vaultKey,
    platform: 'youtube',
    externalId: channel.id,
    email: userData.email || '',
    displayName: channel.snippet?.title || 'YouTube channel',
    username: channel.snippet?.customUrl || '',
    metadata: {
      channel_id: channel.id,
      thumbnail: channel.snippet?.thumbnails?.default?.url || '',
      subscribers: Number(channel.statistics?.subscriberCount || 0),
      videos: Number(channel.statistics?.videoCount || 0),
      views: Number(channel.statistics?.viewCount || 0),
      oauth_scopes: scopes,
    },
  };
}
function saveTikTokClient(config) {
  const clientKey = String(config?.clientKey || '').trim();
  const clientSecret = String(config?.clientSecret || '').trim();
  if (!clientKey || !clientSecret) throw new Error('TikTok Client Key and Client Secret are required.');
  const requested = Array.isArray(config?.scopes) ? config.scopes.map(String) : [];
  const scopes = ['user.info.basic', ...requested.filter(s => ['video.list','video.upload','video.publish','user.info.profile','user.info.stats'].includes(s))]
    .filter((v, i, a) => a.indexOf(v) === i);
  secureSaveJson('oauth:tiktok:client', { client_key: clientKey, client_secret: clientSecret, scopes });
  return { ok: true, clientKeyHint: `${clientKey.slice(0, 6)}…${clientKey.slice(-4)}`, scopes };
}
function updateTikTokScopes(scopesInput) {
  const client = secureGetJson('oauth:tiktok:client');
  if (!client) throw new Error('Configure TikTok developer credentials first.');
  const requested = Array.isArray(scopesInput) ? scopesInput.map(String) : [];
  const scopes = ['user.info.basic', ...requested.filter(s => ['video.list','video.upload','video.publish','user.info.profile','user.info.stats'].includes(s))]
    .filter((v, i, a) => a.indexOf(v) === i);
  secureSaveJson('oauth:tiktok:client', { ...client, scopes });
  return { ok: true, scopes };
}
function tiktokClientStatus() {
  try {
    const c = secureGetJson('oauth:tiktok:client');
    return c ? { configured: true, clientKeyHint: `${c.client_key.slice(0, 6)}…${c.client_key.slice(-4)}`, scopes: c.scopes || ['user.info.basic'] } : { configured: false, scopes: ['user.info.basic'] };
  } catch (e) { return { configured: false, error: String(e), scopes: ['user.info.basic'] }; }
}
async function connectTikTokAccount() {
  const client = secureGetJson('oauth:tiktok:client');
  if (!client) throw new Error('Configure your TikTok Developer Client Key and Client Secret first.');
  const verifier = b64url(crypto.randomBytes(48));
  // TikTok Desktop Login Kit currently documents the PKCE challenge as SHA-256 hex.
  const challenge = crypto.createHash('sha256').update(verifier).digest('hex');
  const state = b64url(crypto.randomBytes(24));
  const server = http.createServer();
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  const address = server.address();
  const redirectUri = `http://127.0.0.1:${address.port}/callback/`;
  const scopes = Array.isArray(client.scopes) && client.scopes.length ? client.scopes : ['user.info.basic'];
  const authUrl = new URL('https://www.tiktok.com/v2/auth/authorize/');
  authUrl.searchParams.set('client_key', client.client_key);
  authUrl.searchParams.set('scope', scopes.join(','));
  authUrl.searchParams.set('response_type', 'code');
  authUrl.searchParams.set('redirect_uri', redirectUri);
  authUrl.searchParams.set('state', state);
  authUrl.searchParams.set('code_challenge', challenge);
  authUrl.searchParams.set('code_challenge_method', 'S256');

  const code = await new Promise(async (resolve, reject) => {
    const timeout = setTimeout(() => { try { server.close(); } catch (_) {} reject(new Error('TikTok authorization timed out.')); }, 5 * 60 * 1000);
    server.on('request', (req, res) => {
      try {
        const u = new URL(req.url, redirectUri);
        if (u.pathname !== '/callback/' && u.pathname !== '/callback') {
          res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Not found'); return;
        }
        if (u.searchParams.get('error')) throw new Error(`TikTok authorization failed: ${u.searchParams.get('error_description') || u.searchParams.get('error')}`);
        if (u.searchParams.get('state') !== state) throw new Error('TikTok OAuth state mismatch. Please retry.');
        const value = u.searchParams.get('code');
        if (!value) throw new Error('TikTok did not return an authorization code.');
        clearTimeout(timeout);
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end('<!doctype html><html><body style="font-family:system-ui;background:#0b0d12;color:#fff;padding:40px"><h2>CLIP OS connected to TikTok</h2><p>You can close this tab and return to CLIP OS.</p></body></html>');
        server.close(); resolve(value);
      } catch (e) {
        clearTimeout(timeout); res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end(String(e)); server.close(); reject(e);
      }
    });
    try { await shell.openExternal(authUrl.toString()); } catch (e) { clearTimeout(timeout); server.close(); reject(e); }
  });

  const tokenBody = new URLSearchParams({
    client_key: client.client_key,
    client_secret: client.client_secret,
    code,
    grant_type: 'authorization_code',
    redirect_uri: redirectUri,
    code_verifier: verifier,
  });
  const tokenRes = await fetch('https://open.tiktokapis.com/v2/oauth/token/', {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: tokenBody.toString(),
  });
  const tokens = await tokenRes.json();
  if (!tokenRes.ok || !tokens.access_token) throw new Error(tokens.error_description || tokens.error || 'TikTok token exchange failed.');

  const grantedScopes = String(tokens.scope || scopes.join(',')).split(',').map(s => s.trim()).filter(Boolean);
  const fields = ['open_id','avatar_url','display_name'];
  if (grantedScopes.includes('user.info.profile')) fields.push('username','profile_deep_link','bio_description','is_verified');
  if (grantedScopes.includes('user.info.stats')) fields.push('follower_count','following_count','likes_count','video_count');
  const userRes = await fetch(`https://open.tiktokapis.com/v2/user/info/?fields=${encodeURIComponent(fields.join(','))}`, {
    headers: { Authorization: `Bearer ${tokens.access_token}` },
  });
  const userData = await userRes.json();
  if (!userRes.ok || (userData?.error?.code && userData.error.code !== 'ok')) throw new Error(userData?.error?.message || 'Could not read TikTok profile.');
  const user = userData?.data?.user || {};
  const openId = user.open_id || tokens.open_id;
  if (!openId) throw new Error('TikTok did not return an OpenID for this account.');
  const vaultKey = `oauth:tiktok:${openId}`;
  secureSaveJson(vaultKey, { ...tokens, scopes: grantedScopes, client_key: client.client_key, obtained_at: new Date().toISOString(), open_id: openId });
  return {
    ok: true, vaultKey, platform: 'tiktok', externalId: openId, email: '',
    displayName: user.display_name || 'TikTok account', username: user.username || '',
    metadata: {
      open_id: openId, avatar_url: user.avatar_url || '', profile_deep_link: user.profile_deep_link || '',
      followers: Number(user.follower_count || 0), following: Number(user.following_count || 0),
      likes: Number(user.likes_count || 0), videos: Number(user.video_count || 0), verified: Boolean(user.is_verified || false),
      oauth_scopes: grantedScopes,
      can_upload_draft: grantedScopes.includes('video.upload'),
      can_direct_post: grantedScopes.includes('video.publish'),
      posting_note: grantedScopes.includes('video.publish') ? 'Direct Post scope granted; TikTok audit rules still apply.' : 'Connect video.upload or video.publish scope in TikTok Developer Portal to enable posting later.',
    },
  };
}

function registerIpc() {
  ipcMain.on('runtime:getConfig', (event) => {
    event.returnValue = { apiBase: `http://127.0.0.1:${backendPort}`, apiToken, version: app.getVersion() };
  });
  ipcMain.handle('vault:available', () => safeStorage.isEncryptionAvailable());
  ipcMain.handle('vault:save', (_event, entry) => {
    if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows secure storage is not available');
    const key = String(entry?.key || '').trim();
    if (!key) throw new Error('Missing vault key');
    const data = readVault();
    data[key] = {
      username: String(entry?.username || ''),
      password: safeStorage.encryptString(String(entry?.password || '')).toString('base64'),
      updatedAt: new Date().toISOString(),
    };
    writeVault(data);
    return { ok: true };
  });
  ipcMain.handle('vault:get', (_event, key) => {
    if (!safeStorage.isEncryptionAvailable()) throw new Error('Windows secure storage is not available');
    const item = readVault()[String(key)];
    if (!item) return null;
    return { username: item.username || '', password: safeStorage.decryptString(Buffer.from(item.password, 'base64')) };
  });
  ipcMain.handle('vault:remove', (_event, key) => { const data = readVault(); delete data[String(key)]; writeVault(data); return { ok: true }; });
  ipcMain.handle('vault:list', () => Object.entries(readVault()).map(([key, v]) => ({ key, username: v.username || '', updatedAt: v.updatedAt || '' })));
  ipcMain.handle('oauth:youtubeStatus', () => youtubeClientStatus());
  ipcMain.handle('oauth:importYouTubeClient', () => importYouTubeClient());
  ipcMain.handle('oauth:connectYouTube', () => connectYouTubeAccount());
  ipcMain.handle('oauth:tiktokStatus', () => tiktokClientStatus());
  ipcMain.handle('oauth:saveTikTokClient', (_event, config) => saveTikTokClient(config));
  ipcMain.handle('oauth:updateTikTokScopes', (_event, scopes) => updateTikTokScopes(scopes));
  ipcMain.handle('oauth:connectTikTok', () => connectTikTokAccount());
  ipcMain.handle('app:openExternal', async (_event, value) => {
    const url = new URL(String(value));
    if (!['https:', 'http:'].includes(url.protocol)) throw new Error('Only http(s) links can be opened.');
    await shell.openExternal(url.toString());
    return { ok: true };
  });
  ipcMain.handle('app:openApiPath', async (_event, value) => {
    const apiPath = String(value || '');
    if (!/^\/(sources|clips)\/[a-f0-9-]+\/file$/i.test(apiPath)) throw new Error('Invalid media preview path.');
    const url = new URL(apiPath, `http://127.0.0.1:${backendPort}`);
    url.searchParams.set('access_token', apiToken);
    await shell.openExternal(url.toString());
    return { ok: true };
  });
  ipcMain.handle('app:openFolder', async (_event, kind) => {
    const roots = {
      media: path.join(app.getPath('videos'), 'ClipOS'),
      state: path.join(app.getPath('appData'), 'ClipOS'),
      logs: path.join(app.getPath('appData'), 'ClipOS', 'Logs'),
    };
    const target = roots[String(kind)];
    if (!target) throw new Error('Unknown CLIP OS folder.');
    fs.mkdirSync(target, { recursive: true });
    const error = await shell.openPath(target);
    if (error) throw new Error(error);
    return { ok: true };
  });
}


function reserveLocalPort() {
  return new Promise((resolve, reject) => {
    const server = http.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      server.close((err) => err ? reject(err) : resolve(address.port));
    });
  });
}

function waitForHealth(timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const started = Date.now();
    const tick = () => {
      const req = http.get({ hostname: '127.0.0.1', port: backendPort, path: '/health', headers: { 'X-ClipOS-Token': apiToken } }, (res) => {
        if (res.statusCode === 200) return resolve(true);
        res.resume();
        retry();
      });
      req.on('error', retry);
    };
    const retry = () => {
      if (Date.now() - started > timeoutMs) return reject(new Error('Backend health check timed out'));
      setTimeout(tick, 350);
    };
    tick();
  });
}

function startBackend() {
  if (!app.isPackaged) return;
  const resources = process.resourcesPath;
  const backendExe = path.join(resources, 'backend', 'clipos-backend.exe');
  const binDir = path.join(resources, 'bin');
  const stateDir = path.join(app.getPath('appData'), 'ClipOS');
  const mediaRoot = path.join(app.getPath('videos'), 'ClipOS');
  fs.mkdirSync(stateDir, { recursive: true });
  fs.mkdirSync(mediaRoot, { recursive: true });
  if (!fs.existsSync(backendExe)) {
    throw new Error(`Missing backend executable: ${backendExe}`);
  }
  const logsDir = path.join(stateDir, 'Logs');
  fs.mkdirSync(logsDir, { recursive: true });
  const stdoutLog = fs.openSync(path.join(logsDir, 'backend.log'), 'a');
  const stderrLog = fs.openSync(path.join(logsDir, 'backend-error.log'), 'a');
  backend = spawn(backendExe, [], {
    windowsHide: true,
    stdio: ['ignore', stdoutLog, stderrLog],
    env: {
      ...process.env,
      CLIPOS_PORT: String(backendPort),
      CLIPOS_API_TOKEN: apiToken,
      CLIPOS_APP_VERSION: app.getVersion(),
      CLIPOS_STATE_DIR: stateDir,
      CLIPOS_MEDIA_ROOT: mediaRoot,
      CLIPOS_BIN_DIR: binDir,
    },
  });
  fs.closeSync(stdoutLog);
  fs.closeSync(stderrLog);
  backend.once('exit', (code) => {
    if (!app.isQuitting && code !== 0 && mainWindow && !mainWindow.isDestroyed()) {
      dialog.showErrorBox('CLIP OS engine stopped', `The local engine exited unexpectedly (code ${code}). Open System Health → Logs for details.`);
    }
  });
  backend.once('error', (err) => {
    try { fs.appendFileSync(path.join(logsDir, 'backend-error.log'), `\n${new Date().toISOString()} spawn error: ${String(err && err.stack ? err.stack : err)}\n`); } catch (_) {}
  });
}

async function createWindow() {
  const win = new BrowserWindow({
    width: 1480,
    height: 920,
    minWidth: 1100,
    minHeight: 720,
    backgroundColor: '#090b0f',
    show: false,
    autoHideMenuBar: true,
    title: 'CLIP OS',
    webPreferences: { contextIsolation: true, sandbox: true, preload: path.join(__dirname, 'preload.cjs') },
  });
  mainWindow = win;
  win.webContents.session.setPermissionRequestHandler((_webContents, _permission, callback) => callback(false));
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(({ url }) => {
    try {
      const target = new URL(url);
      if (['https:', 'http:'].includes(target.protocol)) shell.openExternal(target.toString());
    } catch (_) {}
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (event, url) => {
    const current = win.webContents.getURL();
    if (url !== current) event.preventDefault();
  });
  if (app.isPackaged) {
    await win.loadFile(path.join(__dirname, '..', 'frontend', 'dist', 'index.html'));
  } else {
    await win.loadURL('http://localhost:5173');
  }
}

app.whenReady().then(async () => {
  if (!hasSingleInstanceLock) return;
  registerIpc();
  try {
    if (app.isPackaged) {
      backendPort = await reserveLocalPort();
      startBackend();
      await waitForHealth();
    }
    await createWindow();
    updaterController = createUpdater({ app, ipcMain, getWindow: () => mainWindow });
    updaterController.autoCheckSoon();
  } catch (err) {
    dialog.showErrorBox('CLIP OS could not start', String(err && err.stack ? err.stack : err));
    app.quit();
  }
  app.on('activate', async () => {
    if (BrowserWindow.getAllWindows().length === 0) await createWindow();
  });
});

app.on('before-quit', () => {
  app.isQuitting = true;
  if (backend && !backend.killed) {
    try { backend.kill(); } catch (_) {}
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
