param([switch]$SkipInstall)

$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

function Need($name,$hint) {
  if (-not (Get-Command $name -ErrorAction SilentlyContinue)) { throw "$name is required. $hint" }
}

function Run-Native([scriptblock]$Command, [string]$ErrorMessage) {
  & $Command
  if ($LASTEXITCODE -ne 0) {
    throw "$ErrorMessage (exit code $LASTEXITCODE)"
  }
}

Need node 'Install Node.js LTS: winget install OpenJS.NodeJS.LTS'
Need npm 'npm should be installed with Node.js.'
if (-not (Test-Path '.venv\Scripts\python.exe')) { throw 'Python environment missing. Run .\setup.ps1 first.' }

Write-Host '[1/6] Installing build dependencies...' -ForegroundColor Cyan
if (-not $SkipInstall) {
  if (Test-Path 'package-lock.json') { npm ci } else { npm install }
  if ($LASTEXITCODE -ne 0) { throw "Root npm install failed (exit code $LASTEXITCODE)" }
  if (Test-Path 'frontend\package-lock.json') { npm --prefix frontend ci } else { npm --prefix frontend install }
  if ($LASTEXITCODE -ne 0) { throw "Frontend npm install failed (exit code $LASTEXITCODE)" }
  & .\.venv\Scripts\python.exe -m pip install --upgrade pyinstaller
  if ($LASTEXITCODE -ne 0) { throw "PyInstaller installation failed (exit code $LASTEXITCODE)" }
}

& .\.venv\Scripts\python.exe scripts\verify_project.py
if ($LASTEXITCODE -ne 0) { throw "Project verification failed (exit code $LASTEXITCODE)" }

Write-Host '[2/6] Building React UI...' -ForegroundColor Cyan
Remove-Item -Recurse -Force frontend\dist -ErrorAction SilentlyContinue
npm run build-ui
if ($LASTEXITCODE -ne 0) {
  throw "Frontend build failed. Fix the TypeScript/Vite error shown above, then run .\build-installer.ps1 again. (exit code $LASTEXITCODE)"
}
if (-not (Test-Path 'frontend\dist\index.html')) {
  throw 'Frontend build returned success but frontend\dist\index.html was not created.'
}

Write-Host '[3/6] Compiling local backend to Windows EXE...' -ForegroundColor Cyan
Remove-Item -Recurse -Force resources\backend -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force resources\backend | Out-Null
& .\.venv\Scripts\python.exe -m PyInstaller `
  --noconfirm --clean --onefile --name clipos-backend `
  --paths backend `
  --collect-all fastapi --collect-all uvicorn --collect-all pydantic --collect-all yt_dlp `
  --distpath resources\backend --workpath .build\pyinstaller --specpath .build `
  backend\entry.py
if ($LASTEXITCODE -ne 0) { throw "Backend EXE build failed (exit code $LASTEXITCODE)" }
if (-not (Test-Path 'resources\backend\clipos-backend.exe')) { throw 'Backend EXE was not created.' }

Write-Host '[4/6] Bundling FFmpeg and FFprobe...' -ForegroundColor Cyan
Remove-Item -Recurse -Force resources\bin -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force resources\bin | Out-Null
$ffmpegCmd = Get-Command ffmpeg -ErrorAction SilentlyContinue
$ffprobeCmd = Get-Command ffprobe -ErrorAction SilentlyContinue
$ffmpeg = if ($ffmpegCmd) { $ffmpegCmd.Source } else { $null }
$ffprobe = if ($ffprobeCmd) { $ffprobeCmd.Source } else { $null }
if (-not $ffmpeg -or -not $ffprobe) {
  throw 'FFmpeg/FFprobe not found. Install them, reopen PowerShell, then run this build again.'
}
Copy-Item $ffmpeg resources\bin\ffmpeg.exe -Force
Copy-Item $ffprobe resources\bin\ffprobe.exe -Force

Write-Host '[5/6] Validating packaged resources...' -ForegroundColor Cyan
$required = @(
  'frontend\dist\index.html',
  'resources\backend\clipos-backend.exe',
  'resources\bin\ffmpeg.exe',
  'resources\bin\ffprobe.exe'
)
foreach($f in $required){
  if(-not (Test-Path $f)){ throw "Missing build resource: $f" }
}

Write-Host '[6/6] Building Windows NSIS installer...' -ForegroundColor Cyan
Remove-Item -Recurse -Force release -ErrorAction SilentlyContinue
npm run dist
if ($LASTEXITCODE -ne 0) { throw "Electron Builder/NSIS failed (exit code $LASTEXITCODE)" }

$pkg = Get-Content package.json -Raw | ConvertFrom-Json
$installer = Get-Item ("release\CLIP-OS-Setup-$($pkg.version).exe") -ErrorAction SilentlyContinue
if (-not $installer) { throw 'Installer build finished but expected EXE was not found.' }
if (-not (Test-Path 'release\latest.yml')) { throw 'Update metadata latest.yml was not generated.' }
Write-Host ''
Write-Host 'SUCCESS' -ForegroundColor Green
Write-Host "Installer: $($installer.FullName)" -ForegroundColor Green
Write-Host "Update metadata: $((Resolve-Path 'release\latest.yml').Path)" -ForegroundColor Green
Write-Host 'Your database/media are stored outside the install directory and survive upgrades/reinstalls.'
