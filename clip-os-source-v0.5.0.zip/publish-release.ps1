$ErrorActionPreference = 'Stop'

function Assert-LastExitCode([string]$label) {
  if ($LASTEXITCODE -ne 0) { throw "$label failed (exit code $LASTEXITCODE)." }
}

function Test-GhCommand([string[]]$Arguments) {
  $quoted = $Arguments | ForEach-Object { if ($_ -match '\s') { '"' + $_ + '"' } else { $_ } }
  cmd /c ("gh " + ($quoted -join ' ') + " >nul 2>nul")
  return ($LASTEXITCODE -eq 0)
}

$pkg = Get-Content package.json -Raw | ConvertFrom-Json
$version = $pkg.version
$owner = if ($env:CLIPOS_GH_OWNER) { $env:CLIPOS_GH_OWNER } else { 'lucianleanca10-arch' }
$repo = if ($env:CLIPOS_GH_REPO) { $env:CLIPOS_GH_REPO } else { 'clip-os-releases' }
$fullRepo = "$owner/$repo"

if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
  throw "GitHub CLI (gh) is required. Install it with: winget install GitHub.cli"
}
if (-not (Test-GhCommand @('auth','status'))) {
  Write-Host 'GitHub login required...'
  & gh auth login
  Assert-LastExitCode 'GitHub login'
}
if (-not (Test-GhCommand @('repo','view',$fullRepo))) {
  Write-Host "Creating release repository $fullRepo..."
  & gh repo create $fullRepo --public --description 'CLIP OS release channel and auto-update artifacts' --add-readme
  Assert-LastExitCode 'GitHub repository creation'
}

Write-Host "[1/3] Building installer and update metadata for v$version..."
& .\build-installer.ps1

$setup = Join-Path $PWD "release\CLIP-OS-Setup-$version.exe"
$latest = Join-Path $PWD 'release\latest.yml'
$blockmap = "$setup.blockmap"
if (-not (Test-Path $setup)) { throw "Missing installer: $setup" }
if (-not (Test-Path $latest)) { throw "Missing update metadata: $latest" }
$assets = @($setup,$latest)
if (Test-Path $blockmap) { $assets += $blockmap }

$tag = "v$version"
Write-Host "[2/3] Publishing GitHub release $tag..."
if (Test-GhCommand @('release','view',$tag,'--repo',$fullRepo)) {
  Write-Host 'Release exists; replacing assets...'
  & gh release upload $tag @assets --repo $fullRepo --clobber
  Assert-LastExitCode 'GitHub asset upload'
} else {
  & gh release create $tag @assets --repo $fullRepo --title "CLIP OS $version" --notes "CLIP OS $version"
  Assert-LastExitCode 'GitHub release creation'
}

Write-Host '[3/3] Release published.'
Write-Host "Update feed: https://github.com/$fullRepo/releases/latest/download"
