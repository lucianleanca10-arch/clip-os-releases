from __future__ import annotations

import json
import os
import sqlite3
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    root_package = json.loads((ROOT / "package.json").read_text(encoding="utf-8"))
    ui_package = json.loads((ROOT / "frontend" / "package.json").read_text(encoding="utf-8"))
    expected = root_package["version"]
    assert ui_package["version"] == expected, "Root/frontend versions do not match"

    with tempfile.TemporaryDirectory(prefix="clipos-verify-") as tmp:
        base = Path(tmp)
        state = base / "state"
        state.mkdir(parents=True)
        legacy_db = state / "clipos.db"
        with sqlite3.connect(legacy_db) as con:
            con.executescript(
                """
                CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                INSERT INTO settings(key,value) VALUES('schema_version','7');
                CREATE TABLE sources (
                  id TEXT PRIMARY KEY, filename TEXT NOT NULL, path TEXT NOT NULL,
                  duration REAL, width INTEGER, height INTEGER, fps REAL,
                  created_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'ready',
                  source_url TEXT, source_platform TEXT, rights_confirmed INTEGER NOT NULL DEFAULT 0,
                  metadata_json TEXT NOT NULL DEFAULT '{}'
                );
                INSERT INTO sources(id,filename,path,created_at) VALUES('legacy','legacy.mp4','C:/legacy.mp4','2026-01-01T00:00:00Z');
                """
            )
        os.environ["CLIPOS_STATE_DIR"] = str(state)
        os.environ["CLIPOS_MEDIA_ROOT"] = str(base / "media")
        os.environ["CLIPOS_APP_VERSION"] = expected
        sys.path.insert(0, str(ROOT / "backend"))
        from app import main as clipos  # noqa: PLC0415

        clipos.migrate_db()
        clipos.migrate_db()  # migrations must be safe to run repeatedly
        assert clipos.APP_VERSION == expected
        assert clipos.link_platform("https://youtu.be/dQw4w9WgXcQ") == "youtube"
        assert clipos.link_platform("https://www.tiktok.com/@creator/video/1") == "tiktok"
        assert clipos.link_platform("https://www.instagram.com/reel/example/") == "instagram"
        with sqlite3.connect(clipos.DB_PATH) as con:
            columns = {row[1] for row in con.execute("PRAGMA table_info(sources)")}
            assert {"sha256", "file_size"}.issubset(columns)
            assert con.execute("SELECT filename FROM sources WHERE id='legacy'").fetchone()[0] == "legacy.mp4"
            schema = con.execute("SELECT value FROM settings WHERE key='schema_version'").fetchone()
            assert schema and int(schema[0]) == clipos.SCHEMA_VERSION
        health = clipos.health()
        assert health == {"ok": True, "version": expected, "schema": clipos.SCHEMA_VERSION}

    print(f"CLIP OS {expected} project verification passed")


if __name__ == "__main__":
    main()
