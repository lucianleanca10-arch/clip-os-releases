$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
Write-Host 'Repairing development dependencies...'
if (Test-Path 'node_modules') { Remove-Item -Recurse -Force node_modules }
if (Test-Path 'frontend\node_modules') { Remove-Item -Recurse -Force frontend\node_modules }
npm install
npm --prefix frontend install
& .\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt --upgrade
Write-Host 'Development dependencies repaired.' -ForegroundColor Green
