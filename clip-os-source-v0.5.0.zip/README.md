
## v0.5.0 — Mastered local workflow and reliable updates

This is a data-preserving update from v0.4.5. Install it over the existing app; `%APPDATA%\ClipOS` and `%USERPROFILE%\Videos\ClipOS` stay in place.

- Random local API port plus a per-launch session token blocks unrelated local pages/processes from controlling CLIP OS.
- Single-instance startup, backend crash logs, safer external-link handling and hardened Electron navigation.
- Content Library search, rename, preview, exact duplicate detection and safe source deletion (including derived clips/drafts).
- Clip Studio with exact manual in/out ranges as well as automatic scene candidates.
- Real render profiles: Speed (720p), Balanced (1080p) and Quality (1080p high quality), all with fast-start MP4 output.
- Link Importer cleanup, supported-host validation, size/time limits and duplicate reuse.
- SQLite WAL/busy-timeout reliability and schema v8 migration with automatic pre-migration backup.
- Updater concurrency guards, six-hour background checks and a preconfigured GitHub release channel.
- Reproducible dependency locks, automated migration/security/build checks and a Windows GitHub Actions release pipeline.
- Production dependency audit: zero known npm vulnerabilities at release time.

For the easiest path, install `CLIP-OS-Setup-0.5.0.exe` once. Future versions appear in **Settings → Updates** and install with **Restart & install**.

## v0.4.5 — TikTok Desktop OAuth

This release includes every change from v0.4.3, so you can skip installing 0.4.3 and update directly to 0.4.5.

- Real TikTok Desktop Login Kit integration using OAuth 2.0 + PKCE.
- TikTok Client Key / Client Secret are stored encrypted with Electron/Windows `safeStorage`, never in SQLite.
- Required desktop loopback redirect shown directly in Accounts: `http://127.0.0.1:*/callback/`.
- Connect multiple TikTok accounts; each account gets a separate encrypted access/refresh token vault entry.
- Default identity scope: `user.info.basic`.
- Optional permission toggles for `video.list`, `video.upload`, and `video.publish`. Only request scopes that exist/are approved in your TikTok Developer app.
- Connected TikTok records store non-secret OpenID/profile metadata and capability flags (`can_upload_draft`, `can_direct_post`).
- The app explains the difference between TikTok Login Kit and Content Posting API instead of pretending that login automatically enables publishing.
- Direct Post restrictions are respected: an unaudited TikTok API client may be restricted to private visibility.

See `docs/TIKTOK_SETUP.md` for the exact setup flow.

# CLIP OS Zero v0.4.5 — TikTok OAuth + Trend Radar v2

Trend Radar v2 focuses on **more useful Spanish results and more volume**: configurable scan depth (10–50 per niche), up to 200 visible results, Spanish-first filtering, query expansion for Spanish niches, Balanced/Hot/Discovery presets, minimum views/views-per-hour/engagement controls, transparent score reasons, sorting, and cleanup of old radar results.

# CLIP OS Zero 0.2.0

CLIP OS is a local-first Windows desktop application for clipping, organizing and later publishing short-form content from one command center.

## What 0.2 actually does

- Persistent Get Started onboarding.
- Hardware / FFmpeg / SQLite health checks.
- Local media workspace under `%USERPROFILE%\Videos\ClipOS`.
- Persistent application state under `%APPDATA%\ClipOS`.
- SQLite database with schema versioning and backups.
- Import source videos.
- Local scene-change based clip candidate generation.
- Vertical 1080x1920 rendering with FFmpeg.
- Content Library and clip preview links.
- Local Publisher drafts linked to real rendered clips and platform connector records.
- Accounts status for YouTube, TikTok and Instagram without fake OAuth states.
- Analytics screen that remains empty until real platform metrics exist.
- System Health, manual DB backup and Repair.
- Windows installer build pipeline using PyInstaller + Electron Builder/NSIS.

## What 0.2 intentionally does NOT pretend to do

- No YouTube/TikTok/Instagram OAuth is active yet.
- No social post is sent to a platform yet.
- No social analytics are fabricated.
- Whisper semantic clip ranking is not enabled yet.
- Auto-update transport is not wired to a release repository yet. The installation/data architecture is update-safe, and installing a newer version with the same app ID upgrades the program without deleting `%APPDATA%\ClipOS` or `%USERPROFILE%\Videos\ClipOS`.

## Development

Open PowerShell in this folder:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup.ps1
.\dev.ps1
```

## Build the Windows installer

Run on Windows x64:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup.ps1
.\build-installer.ps1
```

Successful output:

```text
release\CLIP-OS-Setup-0.2.0.exe
```

The installed app does not need Node.js or Python at runtime. The Python backend is packaged to `clipos-backend.exe`; FFmpeg and FFprobe are copied into the app resources at build time.

## Persistent data

Application binaries can be upgraded/reinstalled separately from user data.

```text
%APPDATA%\ClipOS\
  clipos.db
  Backups\
  Logs\

%USERPROFILE%\Videos\ClipOS\
  Inbox\
  Sources\
  Clips\
  Published\
  Temp\
  Cache\
  Captions\
  Thumbnails\
  Backups\
  Logs\
```

Uninstalling CLIP OS does **not** delete these directories by default.

## Repair

Inside the app: **System Health → Repair**.

The v0.2 repair operation:

1. recreates required directories;
2. creates a database backup;
3. checks SQLite integrity;
4. vacuums the database;
5. clears local cache.

Re-running the installer repairs/replaces application binaries while preserving persistent data.

## Upgrade model

Future installers should keep:

- the same `appId`: `com.clipos.zero`;
- a higher semantic `version`;
- `deleteAppDataOnUninstall: false`;
- database migrations instead of deleting/recreating the database.

This lets `0.3.0`, `0.4.2`, etc. replace application binaries while retaining CLIP OS state.

## v0.2.2 — Multi-account setup and publishing drafts

- Account Setup Center starts with an email identity, then walks through platform requirements.
- Opens official signup/developer/OAuth pages in the system browser.
- Multiple account profiles per YouTube, TikTok and Instagram are supported.
- Optional email password vault uses Electron `safeStorage` (Windows-backed encryption) and is not stored in SQLite.
- Social passwords are not collected; official OAuth is the intended authorization path.
- Publisher supports selecting multiple destination accounts at once.
- Metadata is independent by platform: YouTube title/description/hashtags, TikTok caption/hashtags, Instagram caption/hashtags.
- CLIP OS warns when the same clip is selected for multiple accounts on the same network. It does **not** perform invisible hash/audio/color manipulation designed to evade duplicate-content or anti-spam systems. Use genuinely different creative variants instead.

OAuth API calls themselves remain a later connector milestone; account profiles will show `requires_setup` until real authorization is implemented.

## v0.3.0 — updater milestone

This build adds a real Windows NSIS auto-update path using `electron-updater`.

After installing v0.3.0 once, configure **Settings → Updates** with a public GitHub Releases repository you control. Future versions published with `publish-release.ps1` generate and upload `latest.yml`, the NSIS installer and the blockmap. CLIP OS can then check, download and install the newer version from inside the application.

See `docs/AUTO_UPDATE.md`.

## Preconfigured GitHub update channel (v0.3.1)

This build is preconfigured for `lucianleanca10-arch/clip-os-releases`. The repository is intended to be **public and release-only** so installed clients can download `latest.yml`, the NSIS installer, and blockmap without embedding GitHub credentials. Source code does not need to be stored there.

One-time setup on Windows:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup-release-channel.ps1
```

The helper installs/checks GitHub CLI, opens the official GitHub login flow if needed, and creates the release repository when it is missing. Then publish a version with:

```powershell
.\publish-release.ps1
```

CLIP OS v0.3.1+ defaults to that update feed automatically, so users do not need to enter the owner/repository in Settings unless they want to override it.

## v0.4.2 — Trend Radar + Approval Queue

This release adds a local trend-opportunity workflow:

- new **Trend Radar** screen;
- configurable 2h / 3h / 6h discovery windows;
- local hourly scheduler;
- niche and region filters;
- real YouTube Data API adapter;
- views/hour + freshness + engagement + acceleration scoring;
- metric snapshots and scan history in SQLite;
- **Approval Queue** separated from rights clearance;
- rights states for own / authorized / licensed / Creative Commons content;
- explicit source-coverage status for YouTube, TikTok and Instagram;
- dashboard counters for trend opportunities and approvals;
- schema migration to v4;
- fixes missing request models inherited from v0.3.1.

TikTok and Instagram are intentionally shown as limited trend sources in this milestone rather than using brittle scraping or fake data. See `docs/TREND_RADAR.md`.

## v0.4.2 — YouTube OAuth

- Import a Google OAuth **Desktop app** `client_secret.json` from Accounts.
- The OAuth client JSON is encrypted with Electron/Windows `safeStorage` and is not copied into the project or GitHub releases.
- Connect multiple Google/YouTube accounts independently. Google shows the account chooser every time.
- Each YouTube channel receives its own encrypted refresh token in the local vault.
- Connected channels are stored in SQLite only as non-secret metadata plus a vault reference.
- Scopes in this milestone: `openid`, `email`, `youtube.readonly`, and `youtube.upload`.
- Publisher can already select multiple connected account records; the actual YouTube upload action is the next connector milestone.

**Security:** Never commit a downloaded Google OAuth JSON to GitHub. If a client secret was exposed publicly or shared somewhere you do not trust, rotate it in Google Cloud and import the new JSON.


## v0.4.2
- Accounts can be edited from the Accounts screen.
- Trend Radar clearly separates YouTube OAuth credentials from the YouTube Data API key.
- Added API-key test action and clearer source health.
- Release publishing script no longer crashes when a GitHub release does not exist yet.


## v0.4.5 — Link Importer

Adds a rights-first URL importer for public YouTube, TikTok and Instagram Reel links. Paste up to 20 links and CLIP OS imports the best/original media variant exposed by the source into the local Content Library. The importer does not bypass private/login-only media and does not strip embedded watermarks or attribution. Use only media you own or are authorized/licensed to download and reuse.

The backend packages `yt-dlp` and uses the bundled FFmpeg for media merging.
