from __future__ import annotations

import importlib.util
import hashlib
import hmac
import json
import os
import platform
import re
import shutil
import sqlite3
import subprocess
import sys
import uuid
import math
import threading
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

APP_NAME = "ClipOS"
APP_VERSION = os.environ.get("CLIPOS_APP_VERSION", "0.5.0")
SCHEMA_VERSION = 8
API_TOKEN = os.environ.get("CLIPOS_API_TOKEN", "").strip()
HOME = Path.home()
APPDATA = Path(os.environ.get("APPDATA", HOME / "AppData" / "Roaming"))
LOCALAPPDATA = Path(os.environ.get("LOCALAPPDATA", HOME / "AppData" / "Local"))
STATE_DIR = Path(os.environ.get("CLIPOS_STATE_DIR", APPDATA / APP_NAME))
MEDIA_ROOT = Path(os.environ.get("CLIPOS_MEDIA_ROOT", HOME / "Videos" / APP_NAME))
DB_PATH = STATE_DIR / "clipos.db"
CONFIG_PATH = STATE_DIR / "config.json"
FOLDERS = ["Inbox", "Sources", "Clips", "Published", "Temp", "Cache", "Captions", "Thumbnails", "Backups", "Logs"]

app = FastAPI(title="CLIP OS Local API", version=APP_VERSION)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173", "null"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def require_local_session(request: Request, call_next):
    """Reject calls from unrelated local pages/processes in packaged builds."""
    if API_TOKEN and request.method != "OPTIONS":
        supplied = request.headers.get("x-clipos-token", "") or request.query_params.get("access_token", "")
        if not hmac.compare_digest(supplied, API_TOKEN):
            return JSONResponse({"detail": "Invalid CLIP OS local session."}, status_code=401)
    return await call_next(request)


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def ensure_dirs() -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    MEDIA_ROOT.mkdir(parents=True, exist_ok=True)
    for name in FOLDERS:
        (MEDIA_ROOT / name).mkdir(parents=True, exist_ok=True)
    (STATE_DIR / "Backups").mkdir(parents=True, exist_ok=True)
    (STATE_DIR / "Logs").mkdir(parents=True, exist_ok=True)


def db() -> sqlite3.Connection:
    ensure_dirs()
    con = sqlite3.connect(DB_PATH, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA busy_timeout=30000")
    return con


def backup_db(label: str) -> Optional[Path]:
    if not DB_PATH.exists():
        return None
    target = STATE_DIR / "Backups" / f"clipos-{label}-{datetime.now().strftime('%Y%m%d-%H%M%S')}.db"
    shutil.copy2(DB_PATH, target)
    return target


def table_has_column(con: sqlite3.Connection, table: str, column: str) -> bool:
    return any(r[1] == column for r in con.execute(f"PRAGMA table_info({table})").fetchall())


def migrate_db() -> None:
    ensure_dirs()
    with db() as con:
        con.execute("PRAGMA journal_mode=WAL")
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS sources (
              id TEXT PRIMARY KEY, filename TEXT NOT NULL, path TEXT NOT NULL,
              duration REAL, width INTEGER, height INTEGER, fps REAL,
              created_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'ready',
              source_url TEXT, source_platform TEXT, rights_confirmed INTEGER NOT NULL DEFAULT 0,
              metadata_json TEXT NOT NULL DEFAULT '{}'
            );
            CREATE TABLE IF NOT EXISTS clips (
              id TEXT PRIMARY KEY, source_id TEXT NOT NULL, start REAL NOT NULL, end REAL NOT NULL,
              score REAL NOT NULL, reason TEXT, path TEXT, status TEXT NOT NULL DEFAULT 'candidate',
              created_at TEXT NOT NULL, FOREIGN KEY(source_id) REFERENCES sources(id)
            );
            CREATE TABLE IF NOT EXISTS accounts (
              id TEXT PRIMARY KEY, platform TEXT NOT NULL, display_name TEXT NOT NULL,
              status TEXT NOT NULL DEFAULT 'requires_setup', metadata TEXT NOT NULL DEFAULT '{}'
            );
            CREATE TABLE IF NOT EXISTS publications (
              id TEXT PRIMARY KEY, clip_id TEXT, account_id TEXT, platform TEXT NOT NULL,
              remote_id TEXT, state TEXT NOT NULL DEFAULT 'draft', title TEXT, description TEXT,
              error TEXT, created_at TEXT NOT NULL,
              FOREIGN KEY(clip_id) REFERENCES clips(id), FOREIGN KEY(account_id) REFERENCES accounts(id)
            );
            CREATE TABLE IF NOT EXISTS metric_snapshots (
              id INTEGER PRIMARY KEY AUTOINCREMENT, publication_id TEXT NOT NULL,
              captured_at TEXT NOT NULL, views INTEGER, likes INTEGER, comments INTEGER, shares INTEGER
            );
            CREATE TABLE IF NOT EXISTS jobs (
              id TEXT PRIMARY KEY, kind TEXT NOT NULL, state TEXT NOT NULL, progress REAL NOT NULL DEFAULT 0,
              detail TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS trend_items (
              id TEXT PRIMARY KEY, platform TEXT NOT NULL, external_id TEXT NOT NULL, title TEXT NOT NULL,
              source_url TEXT NOT NULL, author TEXT, niche TEXT, region TEXT, published_at TEXT, discovered_at TEXT NOT NULL,
              views INTEGER DEFAULT 0, likes INTEGER DEFAULT 0, comments INTEGER DEFAULT 0, shares INTEGER,
              age_hours REAL DEFAULT 0, velocity REAL DEFAULT 0, acceleration REAL DEFAULT 0, score REAL DEFAULT 0,
              rights_status TEXT NOT NULL DEFAULT 'unknown', review_status TEXT NOT NULL DEFAULT 'new',
              metadata_json TEXT NOT NULL DEFAULT '{}', UNIQUE(platform,external_id)
            );
            CREATE TABLE IF NOT EXISTS trend_snapshots (
              id INTEGER PRIMARY KEY AUTOINCREMENT, trend_id TEXT NOT NULL, captured_at TEXT NOT NULL,
              views INTEGER DEFAULT 0, likes INTEGER DEFAULT 0, comments INTEGER DEFAULT 0, shares INTEGER,
              FOREIGN KEY(trend_id) REFERENCES trend_items(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS trend_runs (
              id TEXT PRIMARY KEY, started_at TEXT NOT NULL, finished_at TEXT, state TEXT NOT NULL,
              detail TEXT, found_count INTEGER NOT NULL DEFAULT 0
            );
            """
        )
        # v3: real multi-account profiles and platform-specific metadata support.
        for col, sqltype in [("email","TEXT"),("username","TEXT"),("label","TEXT"),("setup_stage","TEXT NOT NULL DEFAULT 'identity'"),("vault_key","TEXT")]:
            if not table_has_column(con, "accounts", col):
                con.execute(f"ALTER TABLE accounts ADD COLUMN {col} {sqltype}")
        if not table_has_column(con, "accounts", "external_id"):
            con.execute("ALTER TABLE accounts ADD COLUMN external_id TEXT")
        con.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_accounts_platform_external_id ON accounts(platform, external_id) WHERE external_id IS NOT NULL AND external_id <> ''")
        for col, sqltype in [("source_url","TEXT"),("source_platform","TEXT"),("rights_confirmed","INTEGER NOT NULL DEFAULT 0"),("metadata_json","TEXT NOT NULL DEFAULT '{}' ")]:
            if not table_has_column(con, "sources", col):
                con.execute(f"ALTER TABLE sources ADD COLUMN {col} {sqltype}")
        for col, sqltype in [("file_size", "INTEGER"), ("sha256", "TEXT")]:
            if not table_has_column(con, "sources", col):
                con.execute(f"ALTER TABLE sources ADD COLUMN {col} {sqltype}")
        con.execute("CREATE INDEX IF NOT EXISTS idx_sources_sha256 ON sources(sha256) WHERE sha256 IS NOT NULL AND sha256 <> ''")
        if not table_has_column(con, "publications", "hashtags"):
            con.execute("ALTER TABLE publications ADD COLUMN hashtags TEXT")
        if not table_has_column(con, "publications", "metadata_json"):
            con.execute("ALTER TABLE publications ADD COLUMN metadata_json TEXT NOT NULL DEFAULT '{}'")
        # Remove the old connector placeholder rows; platform templates now live in /platforms.
        con.execute("DELETE FROM accounts WHERE status='requires_setup' AND (email IS NULL OR email='') AND display_name IN ('Youtube','Tiktok','Instagram')")
        current = int((con.execute("SELECT value FROM settings WHERE key='schema_version'").fetchone() or ["0"])[0])
        if current < SCHEMA_VERSION:
            backup_db(f"pre-migration-v{current}-to-v{SCHEMA_VERSION}")
            # Trend Radar v2: the old default score of 70 was too restrictive for discovery.
            old_threshold = con.execute("SELECT value FROM settings WHERE key='trend_score_threshold'").fetchone()
            if old_threshold and str(old_threshold[0]) == "70":
                con.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('trend_score_threshold','45')")
            con.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('schema_version',?)", (str(SCHEMA_VERSION),))
        defaults = {
            "onboarding_step": "0",
            "performance_profile": "balanced",
            "auto_update": "true",
            "media_root": str(MEDIA_ROOT),
            "trend_scan_enabled": "false",
            "trend_scan_minutes": "60",
            "trend_window_hours": "3",
            "trend_region": "ES",
            "trend_niches": "gaming,podcast,dinero,entretenimiento",
            "trend_score_threshold": "45",
            "trend_language": "es",
            "trend_mode": "balanced",
            "trend_scan_depth": "25",
            "trend_result_limit": "60",
            "trend_min_views": "500",
            "trend_min_velocity": "200",
            "trend_min_engagement": "0.8",
            "youtube_api_key": "",
        }
        for k, v in defaults.items():
            con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))


def packaged_tool_path(name: str) -> Optional[str]:
    # Electron sets CLIPOS_BIN_DIR to resources/bin for packaged builds.
    base = os.environ.get("CLIPOS_BIN_DIR")
    if base:
        for candidate in [Path(base) / f"{name}.exe", Path(base) / name]:
            if candidate.exists():
                return str(candidate)
    return shutil.which(name)


def tool_exists(name: str) -> bool:
    return packaged_tool_path(name) is not None


def ffprobe(path: Path) -> dict:
    probe = packaged_tool_path("ffprobe")
    if not probe:
        return {}
    p = subprocess.run([probe, "-v", "quiet", "-print_format", "json", "-show_streams", "-show_format", str(path)], capture_output=True, text=True)
    if p.returncode != 0:
        return {}
    data = json.loads(p.stdout or "{}")
    video = next((s for s in data.get("streams", []) if s.get("codec_type") == "video"), {})
    fps = 0.0
    try:
        a, b = (video.get("r_frame_rate") or "0/1").split("/")
        fps = float(a) / float(b)
    except Exception:
        pass
    try:
        dur = float(data.get("format", {}).get("duration") or 0)
    except Exception:
        dur = 0
    return {"duration": dur, "width": video.get("width"), "height": video.get("height"), "fps": round(fps, 3)}


def gpu_info() -> list[str]:
    smi = shutil.which("nvidia-smi")
    if not smi:
        return []
    p = subprocess.run([smi, "--query-gpu=name,memory.total", "--format=csv,noheader"], capture_output=True, text=True)
    return [x.strip() for x in p.stdout.splitlines() if x.strip()] if p.returncode == 0 else []


def connector_metadata(platform_name: str) -> dict:
    caps = {
        "youtube": ["upload", "sync", "metadata", "analytics"],
        "tiktok": ["upload", "status"],
        "instagram": ["publish", "insights"],
    }
    return {
        "capabilities": caps.get(platform_name, []),
        "note": "OAuth credentials are not configured yet. No account data is fabricated.",
    }


def ensure_connector_rows() -> None:
    with db() as con:
        for plat in ["youtube", "tiktok", "instagram"]:
            if not con.execute("SELECT 1 FROM accounts WHERE platform=?", (plat,)).fetchone():
                con.execute(
                    "INSERT INTO accounts(id,platform,display_name,status,metadata) VALUES(?,?,?,?,?)",
                    (str(uuid.uuid4()), plat, plat.title(), "requires_setup", json.dumps(connector_metadata(plat))),
                )


@app.on_event("startup")
def startup() -> None:
    ensure_dirs()
    migrate_db()
    start_trend_scheduler()


class OnboardingState(BaseModel):
    step: int


class ClipRequest(BaseModel):
    source_id: str
    max_candidates: int = 8
    min_duration: float = 18.0
    max_duration: float = 55.0


class RenderRequest(BaseModel):
    clip_id: str


class ManualClipRequest(BaseModel):
    source_id: str
    start: float
    end: float
    reason: str = "Manual selection"


class SourceUpdateRequest(BaseModel):
    filename: str


class DraftRequest(BaseModel):
    clip_id: str
    account_id: str
    title: str = ""
    description: str = ""


class SettingRequest(BaseModel):
    key: str
    value: str

class AccountCreateRequest(BaseModel):
    platform: str
    email: str
    display_name: str = ""
    username: str = ""
    label: str = ""
    vault_key: str = ""


class AccountUpdateRequest(BaseModel):
    email: Optional[str] = None
    display_name: Optional[str] = None
    username: Optional[str] = None
    label: Optional[str] = None
    status: Optional[str] = None
    setup_stage: Optional[str] = None


class OAuthAccountLinkRequest(BaseModel):
    platform: str
    external_id: str
    email: str = ""
    display_name: str
    username: str = ""
    label: str = ""
    vault_key: str
    metadata: dict = {}


class MultiDraftRequest(BaseModel):
    clip_id: str
    account_ids: list[str]
    metadata_by_platform: dict[str, dict] = {}


class TrendConfigRequest(BaseModel):
    enabled: bool = False
    scan_minutes: int = 60
    window_hours: int = 3
    region: str = "ES"
    niches: list[str] = []
    score_threshold: float = 45.0
    language: str = "es"
    mode: str = "balanced"
    scan_depth: int = 25
    result_limit: int = 60
    min_views: int = 500
    min_velocity: float = 200.0
    min_engagement: float = 0.8
    youtube_api_key: str = ""


class TrendReviewRequest(BaseModel):
    decision: str
    rights_status: Optional[str] = None


class LinkImportRequest(BaseModel):
    url: str
    rights_confirmed: bool = False
    prefer_mp4: bool = True


@app.get("/health")
def health():
    return {"ok": True, "version": APP_VERSION, "schema": SCHEMA_VERSION}


@app.head("/health")
def health_head():
    return None


@app.get("/system")
def system_info():
    ensure_dirs()
    total, used, free = shutil.disk_usage(MEDIA_ROOT)
    integrity = "unknown"
    try:
        with db() as con:
            integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
    except Exception:
        integrity = "error"
    return {
        "version": APP_VERSION,
        "os": platform.platform(),
        "python": sys.version.split()[0],
        "ffmpeg": tool_exists("ffmpeg"),
        "ffprobe": tool_exists("ffprobe"),
        "nvidia_gpus": gpu_info(),
        "cuda_hint": bool(gpu_info()),
        "storage_free_gb": round(free / 1024**3, 1),
        "media_root": str(MEDIA_ROOT),
        "state_dir": str(STATE_DIR),
        "folders_ready": all((MEDIA_ROOT / x).exists() for x in FOLDERS),
        "whisper_installed": importlib.util.find_spec("faster_whisper") is not None,
        "db_integrity": integrity,
        "db_path": str(DB_PATH),
    }


@app.get("/onboarding")
def get_onboarding():
    with db() as con:
        row = con.execute("SELECT value FROM settings WHERE key='onboarding_step'").fetchone()
    return {"step": int(row[0] if row else 0)}


@app.post("/onboarding")
def set_onboarding(s: OnboardingState):
    with db() as con:
        con.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('onboarding_step',?)", (str(s.step),))
    return {"ok": True, "step": s.step}


@app.post("/setup/folders")
def setup_folders():
    ensure_dirs()
    return {"ok": True, "root": str(MEDIA_ROOT), "folders": FOLDERS}


@app.get("/settings")
def settings():
    with db() as con:
        data = {r["key"]: r["value"] for r in con.execute("SELECT * FROM settings").fetchall()}
    # Do not expose stored API keys through the general settings endpoint.
    if "youtube_api_key" in data:
        data["youtube_api_key"] = ""
    return data


@app.post("/settings")
def set_setting(req: SettingRequest):
    with db() as con:
        con.execute("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (req.key, req.value))
    return {"ok": True}


@app.get("/platforms")
def platforms():
    return [
        {
            "id":"youtube","name":"YouTube Shorts","auth":"OAuth 2.0","signup_url":"https://accounts.google.com/signup",
            "developer_url":"https://console.cloud.google.com/apis/library/youtube.googleapis.com",
            "oauth_url":"https://console.cloud.google.com/apis/credentials",
            "requirements":["Create or choose a Google account","Create a Google Cloud project","Enable YouTube Data API v3","Create OAuth credentials for an installed/desktop app","Authorize each YouTube channel separately"],
            "metadata":{"title":True,"description":True,"hashtags":True,"hint":"Use a searchable title and a fuller description with long-tail keywords."}
        },
        {
            "id":"tiktok","name":"TikTok","auth":"OAuth 2.0","signup_url":"https://www.tiktok.com/signup",
            "developer_url":"https://developers.tiktok.com/apps/",
            "oauth_url":"https://developers.tiktok.com/docs/en/login-kit-desktop",
            "requirements":["Create or choose a TikTok account","Register an app in TikTok for Developers","Add Login Kit and configure Desktop","Register redirect URI http://127.0.0.1:*/callback/","Add user.info.basic scope","Add Content Posting API if you want uploads","Request video.upload and/or video.publish only if needed","Authorize each TikTok account separately","Unaudited Direct Post clients are restricted to private viewing"],
            "metadata":{"title":False,"description":True,"hashtags":True,"hint":"Keep the caption concise; use niche-specific hashtags. Trending sound selection remains a TikTok-side choice unless the API exposes it."}
        },
        {
            "id":"instagram","name":"Instagram Reels","auth":"OAuth","signup_url":"https://www.instagram.com/accounts/emailsignup/",
            "developer_url":"https://developers.facebook.com/apps/",
            "oauth_url":"https://developers.facebook.com/docs/instagram-platform/",
            "requirements":["Create or choose an Instagram account","Use a Professional (Creator/Business) account for publishing APIs","Create a Meta developer app","Configure Instagram API permissions/login","Authorize each Instagram account separately"],
            "metadata":{"title":False,"description":True,"hashtags":True,"hint":"Use a readable caption plus a focused block of roughly 3–5 relevant hashtags."}
        }
    ]


@app.get("/accounts")
def accounts():
    with db() as con:
        rows = con.execute("SELECT * FROM accounts ORDER BY platform,COALESCE(label,display_name),display_name").fetchall()
    out=[]
    for r in rows:
        item=dict(r)
        try: item["metadata"]=json.loads(item.get("metadata") or "{}")
        except Exception: item["metadata"]={}
        out.append(item)
    return out


@app.post("/accounts")
def create_account(req: AccountCreateRequest):
    platform_name=req.platform.lower().strip()
    if platform_name not in {"youtube","tiktok","instagram"}:
        raise HTTPException(400,"Unsupported platform")
    if "@" not in req.email:
        raise HTTPException(400,"A valid email address is required")
    aid=str(uuid.uuid4())
    with db() as con:
        con.execute("""INSERT INTO accounts(id,platform,display_name,status,metadata,email,username,label,setup_stage,vault_key)
                       VALUES(?,?,?,?,?,?,?,?,?,?)""",
                    (aid,platform_name,req.display_name.strip() or req.email,"requires_setup",json.dumps(connector_metadata(platform_name)),req.email.strip(),req.username.strip(),req.label.strip(),"identity",req.vault_key.strip()))
    return {"ok":True,"id":aid}


@app.post("/accounts/oauth-link")
def oauth_link_account(req: OAuthAccountLinkRequest):
    platform_name = req.platform.lower().strip()
    if platform_name not in {"youtube","tiktok","instagram"}:
        raise HTTPException(400, "Unsupported platform")
    if not req.external_id.strip():
        raise HTTPException(400, "Missing external account id")
    metadata = connector_metadata(platform_name)
    metadata.update(req.metadata or {})
    with db() as con:
        row = con.execute(
            "SELECT id,label FROM accounts WHERE platform=? AND external_id=?",
            (platform_name, req.external_id.strip()),
        ).fetchone()
        if row:
            aid = row["id"]
            label = req.label.strip() or row["label"] or req.display_name.strip()
            con.execute(
                """UPDATE accounts SET display_name=?,status='connected',metadata=?,email=?,username=?,label=?,
                   setup_stage='connected',vault_key=?,external_id=? WHERE id=?""",
                (
                    req.display_name.strip(),
                    json.dumps(metadata),
                    req.email.strip(),
                    req.username.strip(),
                    label,
                    req.vault_key.strip(),
                    req.external_id.strip(),
                    aid,
                ),
            )
        else:
            aid = str(uuid.uuid4())
            con.execute(
                """INSERT INTO accounts(id,platform,display_name,status,metadata,email,username,label,setup_stage,vault_key,external_id)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    aid,
                    platform_name,
                    req.display_name.strip(),
                    "connected",
                    json.dumps(metadata),
                    req.email.strip(),
                    req.username.strip(),
                    req.label.strip() or req.display_name.strip(),
                    "connected",
                    req.vault_key.strip(),
                    req.external_id.strip(),
                ),
            )
    return {"ok": True, "id": aid, "status": "connected"}


@app.patch("/accounts/{account_id}")
def update_account(account_id:str, req:AccountUpdateRequest):
    allowed={"email":req.email,"display_name":req.display_name,"username":req.username,"label":req.label,"status":req.status,"setup_stage":req.setup_stage}
    pairs=[(k,v) for k,v in allowed.items() if v is not None]
    if not pairs: return {"ok":True}
    with db() as con:
        if not con.execute("SELECT 1 FROM accounts WHERE id=?",(account_id,)).fetchone(): raise HTTPException(404,"Account not found")
        con.execute("UPDATE accounts SET "+",".join(f"{k}=?" for k,_ in pairs)+" WHERE id=?",tuple(v for _,v in pairs)+(account_id,))
    return {"ok":True}


@app.delete("/accounts/{account_id}")
def delete_account(account_id:str):
    with db() as con:
        con.execute("DELETE FROM publications WHERE account_id=?",(account_id,))
        con.execute("DELETE FROM accounts WHERE id=?",(account_id,))
    return {"ok":True}


@app.get("/accounts/{account_id}/requirements")
def account_requirements(account_id: str):
    with db() as con:
        row = con.execute("SELECT platform,email,display_name,status,setup_stage FROM accounts WHERE id=?", (account_id,)).fetchone()
    if not row: raise HTTPException(404, "Account not found")
    info=next((p for p in platforms() if p["id"]==row["platform"]),None)
    return {**(info or {}),"account":dict(row)}


def link_platform(url: str) -> str:
    host = (urllib.parse.urlparse(url).hostname or "").lower().removeprefix("www.")
    if host in {"youtube.com", "m.youtube.com", "youtu.be", "music.youtube.com"} or host.endswith(".youtube.com"):
        return "youtube"
    if host == "tiktok.com" or host.endswith(".tiktok.com"):
        return "tiktok"
    if host == "instagram.com" or host.endswith(".instagram.com"):
        return "instagram"
    raise HTTPException(400, "Only YouTube, TikTok and Instagram links are supported.")


def clean_download_name(value: str) -> str:
    value = re.sub(r"[<>:\\/?*|\"\x00-\x1f]", "_", value or "video")
    value = re.sub(r"\s+", " ", value).strip(" ._")
    return (value[:90] or "video")


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def duplicate_source(sha256: str):
    with db() as con:
        return con.execute("SELECT * FROM sources WHERE sha256=? ORDER BY created_at LIMIT 1", (sha256,)).fetchone()


@app.post("/sources/import-link")
def import_source_link(req: LinkImportRequest):
    """Import media the user owns or is authorized to reuse from a supported URL.

    We request the best/original media variant exposed by the service/extractor. We do
    not strip, conceal or alter embedded watermarks or attribution.
    """
    if not req.rights_confirmed:
        raise HTTPException(400, "Confirm that you own the media or have permission to download/reuse it.")
    url = (req.url or "").strip()
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
        raise HTTPException(400, "Paste a complete http(s) link.")
    platform_name = link_platform(url)
    try:
        import yt_dlp
    except Exception:
        raise HTTPException(503, "Link importer is unavailable in this build. Rebuild CLIP OS with yt-dlp installed.")
    ensure_dirs()
    sid = str(uuid.uuid4())
    temp_dir = MEDIA_ROOT / "Temp" / f"link-{sid}"
    temp_dir.mkdir(parents=True, exist_ok=True)
    ffmpeg_dir = os.environ.get("CLIPOS_BIN_DIR") or str(Path(packaged_tool_path("ffmpeg") or "").parent)
    opts = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "restrictfilenames": False,
        "outtmpl": str(temp_dir / "%(title).100s-%(id)s.%(ext)s"),
        "format": "bv*+ba/b",
        "merge_output_format": "mp4" if req.prefer_mp4 else None,
        "ffmpeg_location": ffmpeg_dir if ffmpeg_dir and Path(ffmpeg_dir).exists() else None,
        "overwrites": False,
        "retries": 2,
        "fragment_retries": 2,
        "max_filesize": 8 * 1024 * 1024 * 1024,
        "socket_timeout": 30,
    }
    opts = {k:v for k,v in opts.items() if v is not None}
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
            requested = info.get("requested_downloads") or []
            paths = []
            for item in requested:
                fp = item.get("filepath")
                if fp: paths.append(Path(fp))
            prepared = Path(ydl.prepare_filename(info))
            paths.extend([prepared, prepared.with_suffix('.mp4'), prepared.with_suffix('.mkv'), prepared.with_suffix('.webm')])
    except Exception as e:
        shutil.rmtree(temp_dir, ignore_errors=True)
        msg = str(e)
        if platform_name == "instagram" and any(x in msg.lower() for x in ["login", "cookie", "sign in"]):
            raise HTTPException(400, "Instagram requires login for this Reel. Public links that the service exposes anonymously can be imported; private/login-only media is not bypassed.")
        raise HTTPException(400, f"Could not import this {platform_name} link: {msg[-500:]}")
    found = next((x for x in paths if x.exists() and x.is_file()), None)
    if not found:
        candidates = sorted((x for x in temp_dir.iterdir() if x.is_file() and x.suffix.lower() in {'.mp4','.mov','.mkv','.webm','.m4v'}), key=lambda x:x.stat().st_size, reverse=True)
        found = candidates[0] if candidates else None
    if not found:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise HTTPException(500, "The download completed but no video file was produced.")
    title = clean_download_name(str(info.get("title") or found.stem))
    ext = found.suffix.lower() if found.suffix else '.mp4'
    checksum = file_sha256(found)
    duplicate = duplicate_source(checksum)
    if duplicate:
        shutil.rmtree(temp_dir, ignore_errors=True)
        return {**dict(duplicate), "platform": duplicate["source_platform"] or platform_name, "duplicate": True, "message": "This exact video is already in your Content Library."}
    dst = MEDIA_ROOT / "Sources" / f"{sid}{ext}"
    shutil.move(str(found), dst)
    shutil.rmtree(temp_dir, ignore_errors=True)
    meta = ffprobe(dst)
    metadata = {
        "extractor": info.get("extractor_key") or info.get("extractor"),
        "webpage_url": info.get("webpage_url") or url,
        "uploader": info.get("uploader") or info.get("channel"),
        "original_title": info.get("title"),
        "duration": info.get("duration"),
        "note": "Imported from the best/original media variant exposed by the service. Embedded watermarks are not removed by CLIP OS.",
    }
    with db() as con:
        con.execute(
            """INSERT INTO sources(id,filename,path,duration,width,height,fps,created_at,status,source_url,source_platform,rights_confirmed,metadata_json,file_size,sha256)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (sid, f"{title}{ext}", str(dst), meta.get("duration"), meta.get("width"), meta.get("height"), meta.get("fps"), now(), "ready", url, platform_name, 1, json.dumps(metadata, ensure_ascii=False), dst.stat().st_size, checksum),
        )
    return {"id": sid, "filename": f"{title}{ext}", "platform": platform_name, "source_url": url, "file_size": dst.stat().st_size, "sha256": checksum, "duplicate": False, **meta}


@app.post("/sources/import")
async def import_source(file: UploadFile = File(...)):
    ensure_dirs()
    ext = Path(file.filename or "video.mp4").suffix.lower()
    if ext not in {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"}:
        raise HTTPException(400, "Formato no soportado")
    sid = str(uuid.uuid4())
    dst = MEDIA_ROOT / "Sources" / f"{sid}{ext}"
    with dst.open("wb") as f:
        while chunk := await file.read(1024 * 1024):
            f.write(chunk)
    checksum = file_sha256(dst)
    duplicate = duplicate_source(checksum)
    if duplicate:
        dst.unlink(missing_ok=True)
        return {**dict(duplicate), "duplicate": True, "message": "This exact video is already in your Content Library."}
    meta = ffprobe(dst)
    with db() as con:
        con.execute(
            "INSERT INTO sources(id,filename,path,duration,width,height,fps,created_at,status,file_size,sha256) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (sid, file.filename, str(dst), meta.get("duration"), meta.get("width"), meta.get("height"), meta.get("fps"), now(), "ready", dst.stat().st_size, checksum),
        )
    return {"id": sid, "filename": file.filename, "file_size": dst.stat().st_size, "sha256": checksum, "duplicate": False, **meta}


@app.get("/sources")
def sources():
    with db() as con:
        rows = con.execute("SELECT * FROM sources ORDER BY created_at DESC").fetchall()
    return [dict(r) for r in rows]


@app.patch("/sources/{source_id}")
def update_source(source_id: str, req: SourceUpdateRequest):
    filename = clean_download_name(req.filename)
    if not filename:
        raise HTTPException(400, "Filename cannot be empty")
    with db() as con:
        if not con.execute("SELECT 1 FROM sources WHERE id=?", (source_id,)).fetchone():
            raise HTTPException(404, "Source not found")
        con.execute("UPDATE sources SET filename=? WHERE id=?", (filename, source_id))
    return {"ok": True, "filename": filename}


@app.delete("/sources/{source_id}")
def delete_source(source_id: str):
    with db() as con:
        row = con.execute("SELECT path FROM sources WHERE id=?", (source_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Source not found")
        clip_rows = con.execute("SELECT id,path FROM clips WHERE source_id=?", (source_id,)).fetchall()
        clip_ids = [r["id"] for r in clip_rows]
        if clip_ids:
            placeholders = ",".join("?" for _ in clip_ids)
            con.execute(f"DELETE FROM publications WHERE clip_id IN ({placeholders})", tuple(clip_ids))
        con.execute("DELETE FROM clips WHERE source_id=?", (source_id,))
        con.execute("DELETE FROM sources WHERE id=?", (source_id,))
    removed = []
    for candidate in [row["path"], *[r["path"] for r in clip_rows if r["path"]]]:
        try:
            path = Path(candidate)
            if path.exists() and MEDIA_ROOT.resolve() in path.resolve().parents:
                path.unlink()
                removed.append(str(path))
        except Exception:
            pass
    return {"ok": True, "removed_files": len(removed)}


@app.get("/sources/{source_id}/file")
def source_file(source_id: str):
    with db() as con:
        row = con.execute("SELECT path FROM sources WHERE id=?", (source_id,)).fetchone()
    if not row or not Path(row[0]).exists():
        raise HTTPException(404)
    return FileResponse(row[0])


def detect_scenes(path: str) -> list[float]:
    ffmpeg = packaged_tool_path("ffmpeg")
    if not ffmpeg:
        return []
    filt = "select='gt(scene,0.32)',showinfo"
    p = subprocess.run([ffmpeg, "-hide_banner", "-i", path, "-vf", filt, "-an", "-f", "null", "-"], capture_output=True, text=True)
    times = []
    for line in p.stderr.splitlines():
        m = re.search(r"pts_time:([0-9.]+)", line)
        if m:
            try:
                times.append(float(m.group(1)))
            except Exception:
                pass
    return sorted(set(times))


@app.post("/clips/analyze")
def analyze_clips(req: ClipRequest):
    with db() as con:
        src = con.execute("SELECT * FROM sources WHERE id=?", (req.source_id,)).fetchone()
    if not src:
        raise HTTPException(404, "Source not found")
    dur = float(src["duration"] or 0)
    if dur <= 1:
        raise HTTPException(400, "No se pudo determinar duración")
    scenes = detect_scenes(src["path"])
    anchors = [0.0] + scenes + [dur]
    candidates = []
    for i, t in enumerate(anchors[1:-1] or [dur / 2]):
        start = max(0, t - 8)
        end = min(dur, start + min(req.max_duration, max(req.min_duration, 35)))
        if end - start < req.min_duration:
            start = max(0, end - req.min_duration)
        proximity = min(1.0, (i + 1) / max(1, len(anchors) - 2))
        score = round(62 + 22 * (1 - proximity / 2) + min(10, len(scenes) / 8), 1)
        candidates.append((score, start, end, "Cambio de escena + ventana compacta"))
    if not candidates:
        step = max(req.min_duration, min(45.0, dur / 4))
        t = 0
        while t < dur and len(candidates) < req.max_candidates:
            candidates.append((60, t, min(dur, t + step), "Segmentación temporal"))
            t += step
    candidates = sorted(candidates, reverse=True)[: req.max_candidates]
    out = []
    with db() as con:
        con.execute("DELETE FROM clips WHERE source_id=? AND status='candidate'", (req.source_id,))
        for score, start, end, reason in candidates:
            cid = str(uuid.uuid4())
            con.execute(
                "INSERT INTO clips(id,source_id,start,end,score,reason,created_at) VALUES(?,?,?,?,?,?,?)",
                (cid, req.source_id, start, end, score, reason, now()),
            )
            out.append({"id": cid, "source_id": req.source_id, "start": round(start, 2), "end": round(end, 2), "score": score, "reason": reason})
    return out


@app.get("/clips")
def clips():
    with db() as con:
        rows = con.execute("SELECT c.*,s.filename source_filename FROM clips c JOIN sources s ON s.id=c.source_id ORDER BY c.created_at DESC").fetchall()
    return [dict(r) for r in rows]


@app.post("/clips/manual")
def create_manual_clip(req: ManualClipRequest):
    with db() as con:
        src = con.execute("SELECT duration FROM sources WHERE id=?", (req.source_id,)).fetchone()
        if not src:
            raise HTTPException(404, "Source not found")
        duration = float(src["duration"] or 0)
        start = max(0.0, float(req.start))
        end = min(duration, float(req.end)) if duration > 0 else float(req.end)
        if end <= start:
            raise HTTPException(400, "End time must be after start time")
        if end - start > 180:
            raise HTTPException(400, "Manual clips are limited to 3 minutes")
        cid = str(uuid.uuid4())
        con.execute(
            "INSERT INTO clips(id,source_id,start,end,score,reason,status,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (cid, req.source_id, start, end, 100, clean_download_name(req.reason) or "Manual selection", "manual", now()),
        )
    return {"ok": True, "id": cid, "start": start, "end": end}


@app.post("/clips/render")
def render_clip(req: RenderRequest):
    ffmpeg = packaged_tool_path("ffmpeg")
    if not ffmpeg:
        raise HTTPException(500, "FFmpeg no disponible")
    with db() as con:
        row = con.execute("SELECT c.*,s.path source_path FROM clips c JOIN sources s ON s.id=c.source_id WHERE c.id=?", (req.clip_id,)).fetchone()
    if not row:
        raise HTTPException(404)
    out = MEDIA_ROOT / "Clips" / f"{req.clip_id}.mp4"
    start = float(row["start"])
    duration = float(row["end"]) - start
    profile = _setting("performance_profile", "balanced")
    profiles = {
        "speed": (720, 1280, "ultrafast", "23", "128k"),
        "balanced": (1080, 1920, "veryfast", "21", "160k"),
        "quality": (1080, 1920, "medium", "18", "192k"),
    }
    width, height, preset, crf, audio_bitrate = profiles.get(profile, profiles["balanced"])
    vf = f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height}"
    cmd = [ffmpeg, "-y", "-ss", str(start), "-i", row["source_path"], "-t", str(duration), "-vf", vf, "-c:v", "libx264", "-preset", preset, "-crf", crf, "-c:a", "aac", "-b:a", audio_bitrate, "-movflags", "+faststart", str(out)]
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        raise HTTPException(500, p.stderr[-2000:])
    with db() as con:
        con.execute("UPDATE clips SET path=?,status='rendered' WHERE id=?", (str(out), req.clip_id))
    return {"ok": True, "path": str(out), "filename": out.name, "profile": profile, "resolution": f"{width}x{height}"}


@app.get("/clips/{clip_id}/file")
def clip_file(clip_id: str):
    with db() as con:
        row = con.execute("SELECT path FROM clips WHERE id=?", (clip_id,)).fetchone()
    if not row or not row[0] or not Path(row[0]).exists():
        raise HTTPException(404)
    return FileResponse(row[0])


@app.get("/publications")
def publications():
    with db() as con:
        rows = con.execute(
            """SELECT p.*,a.display_name account_name,c.path clip_path
               FROM publications p LEFT JOIN accounts a ON a.id=p.account_id
               LEFT JOIN clips c ON c.id=p.clip_id ORDER BY p.created_at DESC"""
        ).fetchall()
    return [dict(r) for r in rows]


@app.post("/publications/draft")
def create_draft(req: DraftRequest):
    with db() as con:
        clip = con.execute("SELECT id,status FROM clips WHERE id=?", (req.clip_id,)).fetchone()
        acc = con.execute("SELECT id,platform FROM accounts WHERE id=?", (req.account_id,)).fetchone()
        if not clip or clip["status"] != "rendered":
            raise HTTPException(400, "Render the clip before adding it to Publisher")
        if not acc:
            raise HTTPException(400, "Account connector not found")
        pid = str(uuid.uuid4())
        con.execute(
            "INSERT INTO publications(id,clip_id,account_id,platform,state,title,description,created_at) VALUES(?,?,?,?,?,?,?,?)",
            (pid, req.clip_id, req.account_id, acc["platform"], "draft", req.title, req.description, now()),
        )
    return {"ok": True, "id": pid, "state": "draft"}


@app.post("/publications/multi-draft")
def multi_draft(req: MultiDraftRequest):
    if not req.account_ids:
        raise HTTPException(400,"Select at least one account")
    with db() as con:
        clip=con.execute("SELECT id,status FROM clips WHERE id=?",(req.clip_id,)).fetchone()
        if not clip: raise HTTPException(404,"Clip not found")
        if clip["status"] != "rendered": raise HTTPException(400,"Render the clip before adding it to Publisher")
        created=[]
        for aid in req.account_ids:
            account=con.execute("SELECT platform FROM accounts WHERE id=?",(aid,)).fetchone()
            if not account: continue
            platform_name=account["platform"]
            md=req.metadata_by_platform.get(platform_name,{}) or {}
            pid=str(uuid.uuid4())
            con.execute("""INSERT INTO publications(id,clip_id,account_id,platform,state,title,description,hashtags,metadata_json,created_at)
                           VALUES(?,?,?,?,?,?,?,?,?,?)""",
                        (pid,req.clip_id,aid,platform_name,"draft",md.get("title","").strip(),md.get("description","").strip(),md.get("hashtags","").strip(),json.dumps(md),now()))
            created.append(pid)
    return {"ok":True,"created":created,"count":len(created)}


@app.get("/analytics/summary")
def analytics_summary():
    with db() as con:
        rows = con.execute(
            """SELECT p.platform, COUNT(DISTINCT p.id) publications,
                      COALESCE(SUM(ms.views),0) views, COALESCE(SUM(ms.likes),0) likes,
                      COALESCE(SUM(ms.comments),0) comments, COALESCE(SUM(ms.shares),0) shares
               FROM publications p
               LEFT JOIN (
                 SELECT m1.* FROM metric_snapshots m1
                 JOIN (SELECT publication_id, MAX(captured_at) mx FROM metric_snapshots GROUP BY publication_id) x
                 ON x.publication_id=m1.publication_id AND x.mx=m1.captured_at
               ) ms ON ms.publication_id=p.id
               GROUP BY p.platform"""
        ).fetchall()
    return [dict(r) for r in rows]


@app.get("/dashboard")
def dashboard():
    with db() as con:
        return {
            "sources": con.execute("SELECT COUNT(*) FROM sources").fetchone()[0],
            "clips": con.execute("SELECT COUNT(*) FROM clips").fetchone()[0],
            "rendered": con.execute("SELECT COUNT(*) FROM clips WHERE status='rendered'").fetchone()[0],
            "accounts": con.execute("SELECT COUNT(*) FROM accounts WHERE status='connected'").fetchone()[0],
            "publications": con.execute("SELECT COUNT(*) FROM publications").fetchone()[0],
            "views": con.execute("SELECT COALESCE(SUM(views),0) FROM (SELECT publication_id,MAX(views) views FROM metric_snapshots GROUP BY publication_id)").fetchone()[0],
            "trend_opportunities": con.execute("SELECT COUNT(*) FROM trend_items WHERE review_status='new'").fetchone()[0],
            "trend_approved": con.execute("SELECT COUNT(*) FROM trend_items WHERE review_status='approved'").fetchone()[0],
        }



# --- Trend Radar -----------------------------------------------------------
TREND_SCAN_LOCK = threading.Lock()
TREND_SCHEDULER_STARTED = False


def _setting(key: str, default: str = "") -> str:
    with db() as con:
        row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return str(row[0]) if row else default


def _save_setting(key: str, value: str) -> None:
    with db() as con:
        con.execute("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (key, value))


def trend_config_dict() -> dict:
    niches = [x.strip() for x in _setting("trend_niches", "gaming,podcast,dinero,entretenimiento").split(",") if x.strip()]
    return {
        "enabled": _setting("trend_scan_enabled", "false").lower() == "true",
        "scan_minutes": max(60, int(_setting("trend_scan_minutes", "60") or 60)),
        "window_hours": max(1, min(24, int(_setting("trend_window_hours", "3") or 3))),
        "region": (_setting("trend_region", "ES") or "ES").upper()[:2],
        "niches": niches,
        "score_threshold": float(_setting("trend_score_threshold", "45") or 45),
        "language": (_setting("trend_language", "es") or "es").lower()[:5],
        "mode": (_setting("trend_mode", "balanced") or "balanced").lower(),
        "scan_depth": max(10, min(50, int(_setting("trend_scan_depth", "25") or 25))),
        "result_limit": max(10, min(200, int(_setting("trend_result_limit", "60") or 60))),
        "min_views": max(0, int(_setting("trend_min_views", "500") or 500)),
        "min_velocity": max(0.0, float(_setting("trend_min_velocity", "200") or 200)),
        "min_engagement": max(0.0, float(_setting("trend_min_engagement", "0.8") or 0.8)),
        "youtube_api_key": _setting("youtube_api_key", ""),
    }


def _iso_to_dt(value: str) -> datetime:
    if not value:
        return datetime.now(timezone.utc)
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _youtube_json(endpoint: str, params: dict) -> dict:
    url = "https://www.googleapis.com/youtube/v3/" + endpoint + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": f"CLIP-OS/{APP_VERSION}"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception as e:
        raise RuntimeError(f"YouTube Data API request failed: {e}")


def _previous_snapshot(con: sqlite3.Connection, trend_id: str):
    return con.execute(
        "SELECT * FROM trend_snapshots WHERE trend_id=? ORDER BY captured_at DESC LIMIT 1",
        (trend_id,),
    ).fetchone()


def _language_looks_spanish(snippet: dict, wanted: str) -> tuple[bool, str]:
    if not wanted or wanted in {"any", "all"}:
        return True, "language:any"
    declared = str(snippet.get("defaultAudioLanguage") or snippet.get("defaultLanguage") or "").lower()
    if declared:
        return declared.startswith(wanted), f"declared:{declared}"
    text = (str(snippet.get("title") or "") + " " + str(snippet.get("description") or "")).lower()
    spanish_markers = {" el "," la "," los "," las "," un "," una "," que "," por "," para "," con "," sin "," como "," cómo "," esto "," esta "," este "," hoy "," ahora "," español "," españa "," porque "," cuando "," dónde "," qué "," más "," también "," nuevo "," nueva "}
    hits = sum(1 for m in spanish_markers if m in f" {text} ")
    accented = any(ch in text for ch in "áéíóúñ¿¡")
    return (hits >= 2 or (hits >= 1 and accented)), f"heuristic:{hits}{'+accent' if accented else ''}"


def _trend_score(views: int, likes: int, comments: int, age_hours: float, previous, now_dt: datetime, window_hours: int) -> tuple[float, float, float, float, list[str]]:
    age = max(0.10, age_hours)
    velocity = views / age
    engagement = ((likes + comments) / max(1, views)) * 100.0
    # More interpretable v2 score: velocity dominates, engagement matters, freshness helps,
    # and repeated snapshots add true acceleration instead of pretending old popularity is trend.
    velocity_score = min(42.0, max(0.0, math.log10(velocity + 1.0) * 10.5))
    engagement_score = min(24.0, max(0.0, engagement * 4.0))
    freshness_score = max(0.0, 14.0 * (1.0 - min(age, window_hours) / max(1.0, window_hours)))
    acceleration = 0.0
    accel_score = 0.0
    recent_velocity = None
    if previous:
        try:
            prev_time = _iso_to_dt(previous["captured_at"])
            elapsed = max(0.08, (now_dt - prev_time).total_seconds() / 3600.0)
            recent_velocity = max(0.0, (views - int(previous["views"] or 0)) / elapsed)
            acceleration = recent_velocity - velocity
            ratio = recent_velocity / max(1.0, velocity)
            if ratio > 1:
                accel_score = min(20.0, (ratio - 1.0) * 16.0)
        except Exception:
            pass
    score = round(min(100.0, velocity_score + engagement_score + freshness_score + accel_score), 1)
    reasons = [f"{velocity:,.0f} views/h", f"{engagement:.1f}% engagement", f"{age:.1f}h old"]
    if recent_velocity is not None:
        reasons.append(f"recent {recent_velocity:,.0f}/h")
        if acceleration > 0:
            reasons.append("accelerating")
    return score, round(velocity, 1), round(acceleration, 1), round(engagement, 2), reasons


def _query_pack(niche: str, language: str) -> list[str]:
    n = niche.strip()
    if language.startswith("es"):
        expansions = {
            "gaming": ["gaming español", "videojuegos españa", "streamer español", "gta fortnite minecraft español"],
            "podcast": ["podcast español", "entrevista podcast españa", "podcast viral español"],
            "dinero": ["dinero españa", "emprendimiento español", "negocios finanzas españa"],
            "entretenimiento": ["viral españa", "entretenimiento español", "streamer polémica españa"],
            "actualidad": ["actualidad españa", "noticia viral españa", "última hora españa"],
            "futbol": ["fútbol españa", "laliga viral", "fútbol español shorts"],
        }
        return expansions.get(n.lower(), [n, f"{n} español", f"{n} españa"])
    return [n]


def scan_youtube_trends(config: dict) -> list[dict]:
    key = config.get("youtube_api_key", "").strip()
    if not key:
        return []
    now_dt = datetime.now(timezone.utc)
    after = now_dt - timedelta(hours=int(config["window_hours"]))
    found: dict[str, dict] = {}
    depth = int(config.get("scan_depth", 25))
    language = str(config.get("language", "es"))
    mode = str(config.get("mode", "balanced"))
    for niche in config.get("niches") or ["trending"]:
        queries = _query_pack(niche, language)
        # Keep API quota reasonable: deep mode explores two query variants per niche; normal modes one.
        query_limit = 2 if mode == "discovery" else 1
        for query in queries[:query_limit]:
            params = {
                "part": "snippet", "type": "video", "order": "viewCount", "maxResults": depth,
                "publishedAfter": after.isoformat().replace("+00:00", "Z"),
                "regionCode": config["region"], "q": query, "videoDuration": "short", "key": key,
            }
            if language not in {"", "any", "all"}:
                params["relevanceLanguage"] = language
            search = _youtube_json("search", params)
            ids = [x.get("id", {}).get("videoId") for x in search.get("items", []) if x.get("id", {}).get("videoId")]
            if not ids:
                continue
            details = _youtube_json("videos", {"part": "snippet,statistics,contentDetails,status", "id": ",".join(ids), "key": key})
            for item in details.get("items", []):
                vid = item.get("id")
                sn = item.get("snippet", {})
                st = item.get("statistics", {})
                published = sn.get("publishedAt", "")
                try:
                    age_hours = max(0.0, (now_dt - _iso_to_dt(published)).total_seconds() / 3600.0)
                except Exception:
                    age_hours = float(config["window_hours"])
                if age_hours > float(config["window_hours"]) + 0.25:
                    continue
                lang_ok, lang_reason = _language_looks_spanish(sn, language)
                if not lang_ok:
                    continue
                views = int(st.get("viewCount") or 0)
                likes = int(st.get("likeCount") or 0)
                comments = int(st.get("commentCount") or 0)
                engagement = ((likes + comments) / max(1, views)) * 100.0
                velocity = views / max(.10, age_hours)
                min_views = int(config.get("min_views", 0))
                min_velocity = float(config.get("min_velocity", 0))
                min_engagement = float(config.get("min_engagement", 0))
                # Discovery is deliberately permissive; Hot only is deliberately strict.
                if mode == "discovery":
                    pass
                elif mode == "hot":
                    if views < max(min_views, 2500) or velocity < max(min_velocity, 750) or engagement < max(min_engagement, 1.5):
                        continue
                else:
                    if views < min_views or velocity < min_velocity or engagement < min_engagement:
                        continue
                candidate = {
                    "platform": "youtube", "external_id": vid, "title": sn.get("title", "Untitled"),
                    "source_url": f"https://www.youtube.com/watch?v={vid}", "author": sn.get("channelTitle", ""),
                    "niche": niche, "region": config["region"], "published_at": published,
                    "views": views, "likes": likes, "comments": comments, "shares": None, "age_hours": age_hours,
                    "metadata": {
                        "thumbnail": ((sn.get("thumbnails") or {}).get("high") or (sn.get("thumbnails") or {}).get("medium") or {}).get("url"),
                        "description": sn.get("description", ""), "license": item.get("status", {}).get("license"),
                        "language": sn.get("defaultAudioLanguage") or sn.get("defaultLanguage") or language,
                        "language_reason": lang_reason, "engagement": round(engagement, 2),
                        "query": query, "duration": (item.get("contentDetails") or {}).get("duration"),
                    },
                }
                old = found.get(vid)
                if not old or candidate["views"] > old["views"]:
                    found[vid] = candidate
    return list(found.values())


def run_trend_scan() -> dict:
    if not TREND_SCAN_LOCK.acquire(blocking=False):
        return {"ok": False, "state": "already_running"}
    run_id = str(uuid.uuid4())
    started = now()
    with db() as con:
        con.execute("INSERT INTO trend_runs(id,started_at,state,detail,found_count) VALUES(?,?,?,?,0)", (run_id, started, "running", "Starting scan"))
    try:
        config = trend_config_dict()
        candidates: list[dict] = []
        errors: list[str] = []
        if config.get("youtube_api_key"):
            try:
                candidates.extend(scan_youtube_trends(config))
            except Exception as e:
                errors.append(str(e))
        else:
            errors.append("YouTube: API key not configured")
        # TikTok Creative Center and Instagram do not expose a general public trend feed through the
        # publishing APIs used by CLIP OS. Their adapters stay explicit instead of scraping pages.
        now_dt = datetime.now(timezone.utc)
        saved = 0
        with db() as con:
            for c in candidates:
                row = con.execute("SELECT id FROM trend_items WHERE platform=? AND external_id=?", (c["platform"], c["external_id"])).fetchone()
                trend_id = row["id"] if row else str(uuid.uuid4())
                prev = _previous_snapshot(con, trend_id) if row else None
                score, velocity, acceleration, engagement, score_reasons = _trend_score(c["views"], c["likes"], c["comments"], float(c["age_hours"]), prev, now_dt, int(config["window_hours"]))
                c["metadata"]["engagement"] = engagement
                c["metadata"]["score_reasons"] = score_reasons
                if row:
                    con.execute("""UPDATE trend_items SET title=?,source_url=?,author=?,niche=?,region=?,published_at=?,views=?,likes=?,comments=?,shares=?,age_hours=?,velocity=?,acceleration=?,score=?,metadata_json=? WHERE id=?""",
                                (c["title"], c["source_url"], c["author"], c["niche"], c["region"], c["published_at"], c["views"], c["likes"], c["comments"], c["shares"], c["age_hours"], velocity, acceleration, score, json.dumps(c["metadata"]), trend_id))
                else:
                    con.execute("""INSERT INTO trend_items(id,platform,external_id,title,source_url,author,niche,region,published_at,discovered_at,views,likes,comments,shares,age_hours,velocity,acceleration,score,metadata_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                                (trend_id, c["platform"], c["external_id"], c["title"], c["source_url"], c["author"], c["niche"], c["region"], c["published_at"], now(), c["views"], c["likes"], c["comments"], c["shares"], c["age_hours"], velocity, acceleration, score, json.dumps(c["metadata"])))
                con.execute("INSERT INTO trend_snapshots(trend_id,captured_at,views,likes,comments,shares) VALUES(?,?,?,?,?,?)", (trend_id, now(), c["views"], c["likes"], c["comments"], c["shares"]))
                if score >= float(config["score_threshold"]):
                    saved += 1
            detail = f"Scanned {len(candidates)} candidates; {saved} at/above threshold."
            if errors:
                detail += " " + " | ".join(errors)
            con.execute("UPDATE trend_runs SET finished_at=?,state=?,detail=?,found_count=? WHERE id=?", (now(), "completed", detail, saved, run_id))
        return {"ok": True, "run_id": run_id, "scanned": len(candidates), "qualified": saved, "detail": detail}
    except Exception as e:
        with db() as con:
            con.execute("UPDATE trend_runs SET finished_at=?,state=?,detail=? WHERE id=?", (now(), "failed", str(e), run_id))
        raise
    finally:
        TREND_SCAN_LOCK.release()


def _scheduler_loop() -> None:
    while True:
        try:
            config = trend_config_dict()
            if config.get("enabled"):
                run_trend_scan()
            time.sleep(max(3600, int(config.get("scan_minutes", 60)) * 60))
        except Exception:
            time.sleep(3600)


def start_trend_scheduler() -> None:
    global TREND_SCHEDULER_STARTED
    if TREND_SCHEDULER_STARTED:
        return
    TREND_SCHEDULER_STARTED = True
    threading.Thread(target=_scheduler_loop, name="clipos-trend-radar", daemon=True).start()


@app.get("/trends/config")
def trends_config():
    c = trend_config_dict()
    # Never echo the full API key back to the UI after saving it.
    key = c.pop("youtube_api_key", "")
    c["youtube_api_key_set"] = bool(key)
    c["youtube_api_key_hint"] = ("••••" + key[-4:]) if key else ""
    return c


@app.post("/trends/config")
def set_trends_config(req: TrendConfigRequest):
    if req.scan_minutes < 60:
        raise HTTPException(400, "Trend scans are limited to once per hour or slower")
    _save_setting("trend_scan_enabled", "true" if req.enabled else "false")
    _save_setting("trend_scan_minutes", str(req.scan_minutes))
    _save_setting("trend_window_hours", str(max(1, min(24, req.window_hours))))
    _save_setting("trend_region", (req.region or "ES").upper()[:2])
    _save_setting("trend_niches", ",".join(x.strip() for x in req.niches if x.strip()))
    _save_setting("trend_score_threshold", str(max(0, min(100, req.score_threshold))))
    _save_setting("trend_language", (req.language or "es").lower()[:5])
    _save_setting("trend_mode", req.mode if req.mode in {"balanced", "hot", "discovery"} else "balanced")
    _save_setting("trend_scan_depth", str(max(10, min(50, req.scan_depth))))
    _save_setting("trend_result_limit", str(max(10, min(200, req.result_limit))))
    _save_setting("trend_min_views", str(max(0, req.min_views)))
    _save_setting("trend_min_velocity", str(max(0.0, req.min_velocity)))
    _save_setting("trend_min_engagement", str(max(0.0, req.min_engagement)))
    if req.youtube_api_key.strip():
        _save_setting("youtube_api_key", req.youtube_api_key.strip())
    return trends_config()




@app.get("/trends/test-youtube-key")
def test_youtube_key():
    key = _setting("youtube_api_key", "").strip()
    if not key:
        raise HTTPException(400, "No YouTube Data API key is saved. OAuth client credentials are separate and cannot be used by Trend Radar.")
    url = "https://www.googleapis.com/youtube/v3/videos?part=id&id=dQw4w9WgXcQ&key=" + urllib.parse.quote(key)
    try:
        data = _json_get(url)
        return {"ok": True, "message": "YouTube Data API key works for public API requests.", "items": len(data.get("items", []))}
    except urllib.error.HTTPError as e:
        try:
            detail = e.read().decode("utf-8", errors="replace")
        except Exception:
            detail = str(e)
        raise HTTPException(e.code, f"YouTube rejected the API key: {detail[:700]}")
    except Exception as e:
        raise HTTPException(502, f"Could not test YouTube API key: {e}")


@app.post("/trends/scan")
def trends_scan():
    return run_trend_scan()


@app.get("/trends/status")
def trends_status():
    cfg = trend_config_dict()
    with db() as con:
        last = con.execute("SELECT * FROM trend_runs ORDER BY started_at DESC LIMIT 1").fetchone()
        counts = con.execute("SELECT review_status,COUNT(*) n FROM trend_items GROUP BY review_status").fetchall()
    return {
        "enabled": cfg["enabled"], "scan_minutes": cfg["scan_minutes"], "window_hours": cfg["window_hours"],
        "mode": cfg["mode"], "language": cfg["language"], "scan_depth": cfg["scan_depth"], "result_limit": cfg["result_limit"],
        "sources": [
            {"platform": "youtube", "state": "ready" if cfg.get("youtube_api_key") else "needs_api_key", "detail": "Official YouTube Data API search + video statistics."},
            {"platform": "tiktok", "state": "limited", "detail": "No general public trend endpoint is wired; CLIP OS does not scrape Creative Center."},
            {"platform": "instagram", "state": "limited", "detail": "No general public Reels trend feed is exposed by the publishing connector."},
        ],
        "last_run": dict(last) if last else None,
        "counts": {r["review_status"]: r["n"] for r in counts},
    }


@app.get("/trends")
def trends(review_status: str = "", limit: int = 0):
    cfg = trend_config_dict()
    sql = "SELECT * FROM trend_items"
    args: list = []
    clauses = ["score>=?"]
    args.append(float(cfg["score_threshold"]))
    if review_status:
        clauses.append("review_status=?")
        args.append(review_status)
    sql += " WHERE " + " AND ".join(clauses) + " ORDER BY score DESC, velocity DESC LIMIT ?"
    effective_limit = int(limit) if int(limit or 0) > 0 else int(cfg.get("result_limit", 60))
    args.append(max(1, min(500, effective_limit)))
    with db() as con:
        rows = con.execute(sql, tuple(args)).fetchall()
    out = []
    for r in rows:
        x = dict(r)
        try: x["metadata"] = json.loads(x.get("metadata_json") or "{}")
        except Exception: x["metadata"] = {}
        x["engagement"] = x["metadata"].get("engagement", round(((int(x.get("likes") or 0)+int(x.get("comments") or 0))/max(1,int(x.get("views") or 0)))*100,2))
        x["score_reasons"] = x["metadata"].get("score_reasons", [])
        x["language"] = x["metadata"].get("language", "")
        out.append(x)
    return out


@app.delete("/trends")
def clear_trends(review_status: str = "new"):
    with db() as con:
        if review_status == "all":
            n = con.execute("SELECT COUNT(*) FROM trend_items").fetchone()[0]
            con.execute("DELETE FROM trend_items")
        else:
            n = con.execute("SELECT COUNT(*) FROM trend_items WHERE review_status=?", (review_status,)).fetchone()[0]
            con.execute("DELETE FROM trend_items WHERE review_status=?", (review_status,))
    return {"ok": True, "deleted": n}


@app.post("/trends/{trend_id}/review")
def review_trend(trend_id: str, req: TrendReviewRequest):
    if req.decision not in {"approved", "rejected", "new"}:
        raise HTTPException(400, "decision must be approved, rejected or new")
    rights = req.rights_status or "unknown"
    if rights not in {"unknown", "own", "licensed", "creative_commons", "authorized"}:
        raise HTTPException(400, "Unsupported rights status")
    with db() as con:
        if not con.execute("SELECT 1 FROM trend_items WHERE id=?", (trend_id,)).fetchone():
            raise HTTPException(404, "Trend item not found")
        con.execute("UPDATE trend_items SET review_status=?,rights_status=? WHERE id=?", (req.decision, rights, trend_id))
    return {"ok": True, "id": trend_id, "decision": req.decision, "rights_status": rights}


@app.get("/trends/runs")
def trend_runs(limit: int = 20):
    with db() as con:
        rows = con.execute("SELECT * FROM trend_runs ORDER BY started_at DESC LIMIT ?", (max(1, min(100, limit)),)).fetchall()
    return [dict(r) for r in rows]


@app.post("/repair/run")
def repair_run():
    ensure_dirs()
    repaired = []
    backup = backup_db("repair")
    with db() as con:
        integrity = con.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise HTTPException(500, f"SQLite integrity check failed: {integrity}")
        con.execute("VACUUM")
    cache = MEDIA_ROOT / "Cache"
    for item in cache.glob("*"):
        try:
            if item.is_dir():
                shutil.rmtree(item)
            else:
                item.unlink()
        except Exception:
            pass
    repaired.extend(["workspace", "database", "cache"])
    return {"ok": True, "repaired": repaired, "backup": str(backup) if backup else None}


@app.post("/backup/create")
def create_backup():
    p = backup_db("manual")
    return {"ok": True, "path": str(p) if p else None}
