import os
import uvicorn

if __name__ == "__main__":
    port = int(os.environ.get("CLIPOS_PORT", "8765"))
    uvicorn.run("app.main:app", host="127.0.0.1", port=port, app_dir=os.path.dirname(__file__), log_level="info")
